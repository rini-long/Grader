"""Срезы и агрегаты отчётности. Числа хранятся в сотых долях единицы."""
from collections import defaultdict
from heapq import nlargest

from engine import MEASURES, in_period

KPI_KEYS = ("volume", "fuel", "hours", "cost")
TOTAL_FIELDS = ("cost", *MEASURES)


def scope_report(report, period=None, equipment_type=None):
    clean = in_period(report["clean"], period)
    if equipment_type:
        clean = [row for row in clean if row.get("equipment_type") == equipment_type]
    return {**report, "clean": clean, "errors": [] if equipment_type else in_period(report["errors"], period)}


def totals(rows):
    sums = dict.fromkeys(TOTAL_FIELDS)
    for row in rows:
        for key in TOTAL_FIELDS:
            if (value := row.get(key)) is not None:
                sums[key] = (sums[key] or 0) + value
    return sums


def previous_month(period):
    if not period:
        return None
    year, month = map(int, period.split("-"))
    if month == 1:
        return f"{year-1:04}-12" if year > 1 else None
    return f"{year:04}-{month-1:02}"


def comparisons(report, rows, period, equipment_type=None):
    # «Весь журнал» не сравниваем с фиктивным предыдущим интервалом:
    # отдельно показываем динамику последнего месяца с данными.
    basis_month = period or max((row["month"] for row in rows if row["month"]), default=None)
    previous = previous_month(basis_month)
    current = totals(in_period(rows, basis_month))
    baseline = totals(scope_report(report, previous, equipment_type)["clean"]) if previous else {}
    result = {}
    for key in KPI_KEYS:
        value, base = current[key], baseline.get(key)
        diff = value - base if value is not None and base is not None else None
        result[key] = {"previous": base, "period": previous, "current_period": basis_month, "whole": not period, "delta": diff,
                       "percent": 100 * diff / base if diff is not None and base else None}
    return result


def workload(clean, scoped):
    """Доли типов, а в центре — выполнение плана при полном покрытии."""
    by_type = defaultdict(lambda: {"hours": 0, "sources": set()})
    for row in clean:
        item = by_type[row["equipment_type"]]
        item["hours"] += row.get("hours") or 0
        item["sources"].add(row["row"])
    with_hours = any(item["hours"] > 0 for item in by_type.values())
    values = [{"name": name, "value": item["hours"] if with_hours else len(item["sources"])}
              for name, item in by_type.items()]
    values.sort(key=lambda e: (-e["value"], e["name"].casefold()))
    base = sum(item["value"] for item in values)
    for item in values:
        item["share"] = item["value"] / base * 100 if base else 0
    # Основная диаграмма ограничена числом секторов; длинный хвост доступен в селекторе.
    items = [item for item in values if item["value"] > 0]
    if len(items) > 8:
        tail = sum(o["value"] for o in items[7:])
        items = [*items[:7], {"name": "Остальные типы", "value": tail, "share": tail / base * 100, "aggregate": True}]
    full_plan = bool(scoped) and all(row.get("plan_hours") is not None and row.get("hours") is not None for row in scoped)
    plan = sum(row["plan_hours"] for row in scoped) if full_plan else 0
    actual = sum(row["hours"] for row in scoped) if plan else None
    return {"basis": "hours" if with_hours else "rows", "total": base, "items": items,
            "types": sorted(by_type, key=str.casefold),
            "utilization": 100 * actual / plan if plan else None, "planned_hours": plan or None, "actual_hours": actual}


def site_totals(rows):
    grouped = {}
    for row in rows:
        name = row["site"]
        row_sum = grouped.setdefault(name, {"name": name, "count": 0, **dict.fromkeys(TOTAL_FIELDS)})
        row_sum["count"] += 1
        for key in TOTAL_FIELDS:
            if (value := row.get(key)) is not None:
                row_sum[key] = (row_sum[key] or 0) + value
    return sorted(grouped.values(), key=lambda e: (-(e["distance"] or 0), -(e["volume"] or 0),
                                                   -(e["cost"] or 0), e["name"].casefold()))


def recent_entries(rows, limit=3):
    latest = {}
    for row in rows:
        # Одна строка Excel может быть распределена по нескольким машинам/участкам.
        # В ленте показываем её один раз, суммируя именно выбранный срез.
        ident = row["row"]
        if ident not in latest:
            latest[ident] = {k: row.get(k) for k in ("date", "row", "machine", "work", "volume", "distance", "status")}
        else:
            entry = latest[ident]
            for k in ("volume", "distance"):
                if row.get(k) is not None:
                    entry[k] = (entry[k] or 0) + row[k]
            if entry["machine"] != row["machine"]:
                entry["machine"] = "Несколько машин"
            if entry["work"] != row["work"]:
                entry["work"] = "Несколько работ"
    return nlargest(limit, latest.values(), key=lambda row: (row["date"] or "", row["row"]))

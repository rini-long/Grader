"""SQLite-хранилище: загрузки, исходные строки, справочники и результаты проверки."""
from contextlib import closing, contextmanager
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory

from engine import equipment_catalog, text


SCHEMA = """
CREATE TABLE IF NOT EXISTS workspace_settings (
    id TEXT PRIMARY KEY,
    threshold REAL NOT NULL CHECK(threshold BETWEEN 0 AND 1),
    hint_min REAL NOT NULL CHECK(hint_min BETWEEN 0 AND threshold),
    split_mode TEXT NOT NULL CHECK(split_mode IN ('equal', 'flag'))
);
CREATE TABLE IF NOT EXISTS imports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id TEXT NOT NULL REFERENCES workspace_settings(id) ON DELETE CASCADE,
    raw_file TEXT NOT NULL,
    ref_file TEXT NOT NULL,
    created_at TEXT NOT NULL,
    raw_count INTEGER NOT NULL,
    clean_count INTEGER NOT NULL,
    error_count INTEGER NOT NULL,
    ref_sites INTEGER NOT NULL,
    ref_machines INTEGER NOT NULL,
    ref_works INTEGER NOT NULL,
    threshold REAL NOT NULL,
    hint_min REAL NOT NULL,
    split_mode TEXT NOT NULL,
    UNIQUE(workspace_id, id)
);
CREATE INDEX IF NOT EXISTS imports_by_workspace ON imports(workspace_id, id DESC);
CREATE TABLE IF NOT EXISTS selected_imports (
    workspace_id TEXT PRIMARY KEY REFERENCES workspace_settings(id) ON DELETE CASCADE,
    import_id INTEGER NOT NULL,
    FOREIGN KEY(workspace_id, import_id) REFERENCES imports(workspace_id, id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS raw_rows (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    row_no INTEGER NOT NULL,
    site, machine, work, cost, date, volume, fuel, hours,
    PRIMARY KEY(import_id, row_no)
);
CREATE TABLE IF NOT EXISTS reference_rows (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    row_no INTEGER NOT NULL,
    site, machine, work,
    PRIMARY KEY(import_id, row_no)
);
CREATE TABLE IF NOT EXISTS clean_rows (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    row_no INTEGER NOT NULL,
    site TEXT NOT NULL, machine TEXT NOT NULL, work TEXT NOT NULL,
    cost INTEGER NOT NULL, date TEXT, volume INTEGER, fuel INTEGER, hours INTEGER,
    note TEXT NOT NULL,
    PRIMARY KEY(import_id, position),
    FOREIGN KEY(import_id, row_no) REFERENCES raw_rows(import_id, row_no) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS error_rows (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    row_no INTEGER NOT NULL,
    date TEXT,
    raw TEXT NOT NULL,
    issue TEXT NOT NULL,
    hint TEXT NOT NULL,
    PRIMARY KEY(import_id, row_no),
    FOREIGN KEY(import_id, row_no) REFERENCES raw_rows(import_id, row_no) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS workspace_backups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id TEXT NOT NULL REFERENCES workspace_settings(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    import_count INTEGER NOT NULL,
    size_bytes INTEGER NOT NULL,
    payload BLOB NOT NULL
);
CREATE INDEX IF NOT EXISTS backups_by_workspace ON workspace_backups(workspace_id, id DESC);
CREATE TABLE IF NOT EXISTS raw_details (
    import_id INTEGER NOT NULL, row_no INTEGER NOT NULL, metadata TEXT NOT NULL,
    PRIMARY KEY(import_id, row_no),
    FOREIGN KEY(import_id, row_no) REFERENCES raw_rows(import_id, row_no) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS reference_details (
    import_id INTEGER NOT NULL, row_no INTEGER NOT NULL, equipment_type TEXT,
    PRIMARY KEY(import_id, row_no),
    FOREIGN KEY(import_id, row_no) REFERENCES reference_rows(import_id, row_no) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS equipment (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    name TEXT NOT NULL, category TEXT NOT NULL, PRIMARY KEY(import_id, name)
);
CREATE TABLE IF NOT EXISTS sites (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    name TEXT NOT NULL, PRIMARY KEY(import_id, name)
);
CREATE TABLE IF NOT EXISTS employees (
    import_id INTEGER NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
    name TEXT NOT NULL, PRIMARY KEY(import_id, name)
);
CREATE TABLE IF NOT EXISTS journal_details (
    import_id INTEGER NOT NULL, position INTEGER NOT NULL,
    distance INTEGER, plan_hours INTEGER, employee TEXT,
    status TEXT NOT NULL CHECK(status IN ('verified', 'completed', 'in_progress', 'attention')),
    PRIMARY KEY(import_id, position),
    FOREIGN KEY(import_id, position) REFERENCES clean_rows(import_id, position) ON DELETE CASCADE,
    FOREIGN KEY(import_id, employee) REFERENCES employees(import_id, name) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS finances (
    import_id INTEGER NOT NULL, position INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount>=0),
    PRIMARY KEY(import_id, position),
    FOREIGN KEY(import_id, position) REFERENCES clean_rows(import_id, position) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS storage_migrations (name TEXT PRIMARY KEY);
"""

INPUT_FIELDS = ("site", "machine", "work", "cost", "date", "volume", "fuel", "hours")
EXTRA_INPUT_FIELDS = ("distance", "plan_hours", "employee", "status")
SETTING_FIELDS = ("threshold", "hint_min", "split_mode")
CHILD_TABLES = ("raw_rows", "reference_rows", "clean_rows", "error_rows", "raw_details", "reference_details",
                "equipment", "sites", "employees", "journal_details", "finances")
SNAPSHOT_TABLES = ("imports", *CHILD_TABLES, "selected_imports")
BACKUP_LIMIT = 5
MAX_BACKUP_BYTES = 64 * 1024 * 1024


class ActiveImportChanged(Exception):
    """Набор изменился в другой вкладке, пока выполнялась проверка."""


def _cell(value):
    # У исходных колонок нет приведения типов: '001' и 1 остаются разными значениями.
    if type(value) is bool or (type(value) is int and not -2**63 <= value < 2**63):
        return str(value)
    return None if isinstance(value, float) and not math.isfinite(value) else value


def _settings(row):
    return {key: row[key] for key in SETTING_FIELDS}


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class Storage:
    backend = "SQLite"

    def __init__(self, path, legacy=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(SCHEMA)
        if legacy:
            self._migrate(*legacy)
        self._catalog_upgrade()

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    @contextmanager
    def _transaction(self, *, write=False):
        with closing(self._connect()) as db, db:
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db

    def _migrate(self, table, data_column, adapter):
        if (table, data_column) not in (("workspace", "payload"), ("workspaces", "data")):
            raise ValueError("Неизвестный формат старого хранилища.")
        with self._transaction(write=True) as db:
            name = f"legacy_{table}_to_imports"
            if db.execute("SELECT 1 FROM storage_migrations WHERE name=?", (name,)).fetchone():
                return
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                for row in db.execute(f"SELECT id, {data_column} FROM {table}"):
                    key = row["id"]
                    if db.execute("SELECT 1 FROM workspace_settings WHERE id=?", (key,)).fetchone():
                        continue
                    old = adapter(json.loads(row[data_column]))
                    self._save_settings(db, key, old["settings"])
                    if old["source"] == "import":
                        self._add(db, key, old)
                # Старый JSON сохранялся только как промежуточный формат. После переноса
                # удаляем его, чтобы удалённые из истории журналы не оставались в этой таблице.
                db.execute(f"DROP TABLE {table}")
            db.execute("INSERT INTO storage_migrations(name) VALUES (?)", (name,))

    @staticmethod
    def _input_cell(value):
        return _cell(value)

    @staticmethod
    def _catalogs(db, import_id, raw, ref):
        for table, rows in (("sites", ((import_id, name) for name in {text(r.get("site")) for r in ref} - {""})),
                            ("employees", ((import_id, name) for name in {text(r.get("employee")) for r in raw} - {""}))):
            db.executemany(f"INSERT INTO {table}(import_id, name) VALUES (?, ?) ON CONFLICT DO NOTHING", rows)
        db.executemany(
            "INSERT INTO equipment(import_id, name, category) VALUES (?, ?, ?) ON CONFLICT DO NOTHING",
            ((import_id, name, kind) for name, kind in equipment_catalog(ref).items()),
        )

    def _catalog_upgrade(self):
        with self._transaction(write=True) as db:
            name = "catalogs_to_1_3"
            if db.execute("SELECT 1 FROM storage_migrations WHERE name=?", (name,)).fetchone():
                return
            ids = [row[0] for row in db.execute("SELECT id FROM imports")]
            for ident in ids:
                ref = self._read_ref(db, ident)
                self._catalogs(db, ident, [], ref)
            db.execute("""INSERT INTO finances(import_id, position, amount)
                          SELECT import_id, position, cost FROM clean_rows WHERE TRUE ON CONFLICT DO NOTHING""")
            db.execute("INSERT INTO storage_migrations(name) VALUES (?)", (name,))

    @staticmethod
    def _save_settings(db, key, settings):
        db.execute(
            """INSERT INTO workspace_settings(id, threshold, hint_min, split_mode) VALUES (?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET threshold=excluded.threshold, hint_min=excluded.hint_min,
                                             split_mode=excluded.split_mode""",
            (key, *(settings[k] for k in SETTING_FIELDS)),
        )

    @staticmethod
    def _select(db, key, import_id):
        db.execute(
            """INSERT INTO selected_imports(workspace_id, import_id) VALUES (?, ?)
               ON CONFLICT(workspace_id) DO UPDATE SET import_id=excluded.import_id""",
            (key, import_id),
        )

    @staticmethod
    def _put_report(db, import_id, report):
        db.executemany(
            """INSERT INTO clean_rows(import_id, position, row_no, site, machine, work, cost, date, volume, fuel, hours, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            ((import_id, idx, row["row"], *(row.get(k) for k in INPUT_FIELDS), row.get("note", ""))
             for idx, row in enumerate(report["clean"], 1)),
        )
        db.executemany(
            "INSERT INTO finances(import_id, position, amount) VALUES (?, ?, ?)",
            ((import_id, pos, row["cost"]) for pos, row in enumerate(report["clean"], 1)),
        )
        db.executemany(
            """INSERT INTO journal_details(import_id, position, distance, plan_hours, employee, status)
               VALUES (?, ?, ?, ?, ?, ?)""",
            ((import_id, pos, row.get("distance"), row.get("plan_hours"), row.get("employee"), row.get("status", "verified"))
             for pos, row in enumerate(report["clean"], 1)),
        )
        db.executemany(
            "INSERT INTO error_rows(import_id, row_no, date, raw, issue, hint) VALUES (?, ?, ?, ?, ?, ?)",
            ((import_id, row["row"], row.get("date") or row.get("month"), row["raw"], row["issue"], row["hint"])
             for row in report["errors"]),
        )

    def _add(self, db, key, workspace):
        settings, report = workspace["settings"], workspace["report"]
        self._save_settings(db, key, settings)
        cursor = db.execute(
            """INSERT INTO imports(workspace_id, raw_file, ref_file, created_at, raw_count, clean_count, error_count,
                                   ref_sites, ref_machines, ref_works, threshold, hint_min, split_mode)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id""",
            (key, workspace["files"]["raw"], workspace["files"]["ref"], workspace.get("updated_at") or _now(),
             len(workspace["raw"]), len(report["clean"]), len(report["errors"]),
             *(report["dict_sizes"][k] for k in ("site", "machine", "work")),
             *(settings[k] for k in SETTING_FIELDS)),
        )
        import_id = cursor.fetchone()[0]
        db.executemany(
            "INSERT INTO raw_rows(import_id, row_no, site, machine, work, cost, date, volume, fuel, hours) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ((import_id, row.get("row", idx), *(self._input_cell(row.get(k)) for k in INPUT_FIELDS))
             for idx, row in enumerate(workspace["raw"], 2)),
        )
        db.executemany(
            "INSERT INTO reference_rows(import_id, row_no, site, machine, work) VALUES (?, ?, ?, ?, ?)",
            ((import_id, row.get("row", idx), *(self._input_cell(row.get(k)) for k in ("site", "machine", "work")))
             for idx, row in enumerate(workspace["ref"], 2)),
        )
        db.executemany(
            "INSERT INTO raw_details(import_id, row_no, metadata) VALUES (?, ?, ?)",
            ((import_id, row.get("row", idx), json.dumps({k: _cell(row.get(k)) for k in EXTRA_INPUT_FIELDS}, ensure_ascii=False))
             for idx, row in enumerate(workspace["raw"], 2) if any(row.get(k) is not None for k in EXTRA_INPUT_FIELDS)),
        )
        db.executemany(
            "INSERT INTO reference_details(import_id, row_no, equipment_type) VALUES (?, ?, ?)",
            ((import_id, row.get("row", idx), text(row["equipment_type"]))
             for idx, row in enumerate(workspace["ref"], 2) if text(row.get("equipment_type"))),
        )
        self._catalogs(db, import_id, workspace["raw"], workspace["ref"])
        self._put_report(db, import_id, report)
        self._select(db, key, import_id)
        return import_id

    def add_import(self, key, workspace):
        with self._transaction(write=True) as db:
            return self._add(db, key, workspace)

    @staticmethod
    def _read_ref(db, import_id):
        return [dict(row) for row in db.execute(
            """SELECT r.row_no AS row, r.site, r.machine, r.work, d.equipment_type FROM reference_rows r
               LEFT JOIN reference_details d ON d.import_id=r.import_id AND d.row_no=r.row_no
               WHERE r.import_id=? ORDER BY r.row_no""", (import_id,))]

    def _hydrate(self, db, item, include_inputs):
        import_id = item["id"]
        clean = [dict(row) for row in db.execute(
            """SELECT c.row_no AS row, c.site, c.machine, c.work, COALESCE(f.amount, c.cost) AS cost,
                      c.date, c.volume, c.fuel, c.hours, c.note, j.distance, j.plan_hours, j.employee,
                      COALESCE(j.status,'verified') AS status, COALESCE(e.category,'Тип не указан') AS equipment_type
               FROM clean_rows c
               LEFT JOIN journal_details j ON j.import_id=c.import_id AND j.position=c.position
               LEFT JOIN finances f ON f.import_id=c.import_id AND f.position=c.position
               LEFT JOIN equipment e ON e.import_id=c.import_id AND e.name=c.machine
               WHERE c.import_id=? ORDER BY c.position""", (import_id,),
        )]
        errors = [dict(row) for row in db.execute(
            "SELECT row_no AS row, date, raw, issue, hint FROM error_rows WHERE import_id=? ORDER BY row_no", (import_id,),
        )]
        for row in (*clean, *errors):
            row["month"] = row["date"][:7] if row["date"] else None
        data = {
            "import_id": import_id, "source": "import", "updated_at": item["created_at"],
            "files": {"raw": item["raw_file"], "ref": item["ref_file"]}, "settings": _settings(item),
            "report": {"clean": clean, "errors": errors,
                       "dict_sizes": {"site": item["ref_sites"], "machine": item["ref_machines"], "work": item["ref_works"]}},
        }
        if include_inputs:
            data["raw"] = [dict(row) for row in db.execute(
                """SELECT r.row_no AS row, r.site, r.machine, r.work, r.cost, r.date, r.volume, r.fuel, r.hours, d.metadata
                   FROM raw_rows r LEFT JOIN raw_details d ON d.import_id=r.import_id AND d.row_no=r.row_no
                   WHERE r.import_id=? ORDER BY r.row_no""", (import_id,),
            )]
            for row in data["raw"]:
                meta = row.pop("metadata")
                if meta:
                    row.update(json.loads(meta))
            data["ref"] = self._read_ref(db, import_id)
        return data

    def current(self, key, include_inputs=False):
        with self._transaction() as db:
            item = db.execute(
                """SELECT i.* FROM selected_imports s JOIN imports i ON i.id=s.import_id
                   WHERE s.workspace_id=?""", (key,),
            ).fetchone()
            if item:
                return self._hydrate(db, item, include_inputs)
            row = db.execute("SELECT * FROM workspace_settings WHERE id=?", (key,)).fetchone()
            return {"import_id": None, "source": "demo", "settings": _settings(row) if row else None}

    def get_settings(self, key):
        with self._transaction() as db:
            row = db.execute("SELECT * FROM workspace_settings WHERE id=?", (key,)).fetchone()
            return _settings(row) if row else None

    def get_import(self, key, import_id, include_inputs=False):
        with self._transaction() as db:
            item = db.execute("SELECT * FROM imports WHERE workspace_id=? AND id=?", (key, import_id)).fetchone()
            return self._hydrate(db, item, include_inputs) if item else None

    def list_imports(self, key, page=1, page_size=10):
        with self._transaction() as db:
            total = db.execute("SELECT COUNT(*) FROM imports WHERE workspace_id=?", (key,)).fetchone()[0]
            pages = max(1, (total + page_size - 1) // page_size)
            page = max(1, min(pages, page))
            rows = db.execute(
                """SELECT i.id, i.raw_file, i.ref_file, i.created_at, i.raw_count, i.clean_count, i.error_count,
                          (s.import_id IS NOT NULL) AS active
                   FROM imports i LEFT JOIN selected_imports s ON s.import_id=i.id
                   WHERE i.workspace_id=? ORDER BY i.id DESC LIMIT ? OFFSET ?""",
                (key, page_size, (page - 1) * page_size),
            )
            return {"rows": [dict(row) for row in rows], "total": total, "page": page, "pages": pages}

    def stats(self, key):
        with self._transaction() as db:
            row = db.execute(
                """SELECT COUNT(*) AS imports_count, COALESCE(SUM(raw_count), 0) AS rows_count
                   FROM imports WHERE workspace_id=?""", (key,),
            ).fetchone()
            return {key: int(value) for key, value in dict(row).items()}

    def activate(self, key, import_id):
        with self._transaction(write=True) as db:
            row = db.execute("SELECT * FROM imports WHERE workspace_id=? AND id=?", (key, import_id)).fetchone()
            if not row:
                return False
            self._save_settings(db, key, _settings(row))
            self._select(db, key, import_id)
            return True

    def show_demo(self, key, settings):
        with self._transaction(write=True) as db:
            self._save_settings(db, key, settings)
            db.execute("DELETE FROM selected_imports WHERE workspace_id=?", (key,))

    def discard(self, key, import_id):
        with self._transaction(write=True) as db:
            return db.execute("DELETE FROM imports WHERE workspace_id=? AND id=?", (key, import_id)).rowcount == 1

    def update_settings(self, key, settings, import_id=None, report=None):
        with self._transaction(write=True) as db:
            current = db.execute("SELECT import_id FROM selected_imports WHERE workspace_id=?", (key,)).fetchone()
            if (current[0] if current else None) != import_id:
                raise ActiveImportChanged
            self._save_settings(db, key, settings)
            if not import_id:
                return
            db.execute("DELETE FROM clean_rows WHERE import_id=?", (import_id,))
            db.execute("DELETE FROM error_rows WHERE import_id=?", (import_id,))
            self._put_report(db, import_id, report)
            db.execute(
                """UPDATE imports SET clean_count=?, error_count=?, threshold=?, hint_min=?, split_mode=?
                   WHERE id=? AND workspace_id=?""",
                (len(report["clean"]), len(report["errors"]), *(settings[k] for k in SETTING_FIELDS), import_id, key),
            )


    def list_backups(self, key):
        with self._transaction() as db:
            return [dict(row) for row in db.execute(
                """SELECT id, created_at, import_count, size_bytes FROM workspace_backups
                   WHERE workspace_id=? ORDER BY id DESC""", (key,))]

    def get_backup(self, key, backup_id):
        with self._transaction() as db:
            row = db.execute(
                "SELECT created_at, payload FROM workspace_backups WHERE workspace_id=? AND id=?",
                (key, backup_id),
            ).fetchone()
            return dict(row) if row else None

    def create_backup(self, key, defaults):
        # Согласованный снимок именно этой рабочей области, без данных других браузеров.
        with TemporaryDirectory(prefix="grader-backup-") as folder:
            path = Path(folder) / "grader.sqlite3"
            try:
                with self._transaction() as source, closing(sqlite3.connect(path)) as copy:
                    copy.execute("PRAGMA foreign_keys=ON")
                    page_size = copy.execute("PRAGMA page_size").fetchone()[0]
                    copy.execute(f"PRAGMA max_page_count={MAX_BACKUP_BYTES // page_size}")
                    copy.executescript(SCHEMA)
                    setting = source.execute("SELECT * FROM workspace_settings WHERE id=?", (key,)).fetchone()
                    self._save_settings(copy, key, _settings(setting) if setting else defaults)
                    imports_count = source.execute("SELECT COUNT(*) FROM imports WHERE workspace_id=?", (key,)).fetchone()[0]
                    for table in SNAPSHOT_TABLES:
                        where = "import_id IN (SELECT id FROM imports WHERE workspace_id=?)" if table in CHILD_TABLES else "workspace_id=?"
                        rows = source.execute(f"SELECT * FROM {table} WHERE {where}", (key,))
                        slots = ",".join("?" for _ in rows.description)
                        copy.executemany(f"INSERT INTO {table} VALUES ({slots})", (_row_values(row) for row in rows))
                    copy.commit()
            except sqlite3.OperationalError as error:
                if getattr(error, "sqlite_errorcode", None) == sqlite3.SQLITE_FULL:
                    raise ValueError("Размер копии превышает 64 МБ. Уменьшите историю загрузок и повторите попытку.") from None
                raise
            payload = path.read_bytes()
        with self._transaction(write=True) as db:
            db.execute(
                "INSERT INTO workspace_settings(id, threshold, hint_min, split_mode) VALUES (?, ?, ?, ?) ON CONFLICT DO NOTHING",
                (key, *(defaults[k] for k in SETTING_FIELDS)),
            )
            db.execute(
                "INSERT INTO workspace_backups(workspace_id, created_at, import_count, size_bytes, payload) VALUES (?, ?, ?, ?, ?)",
                (key, _now(), imports_count, len(payload), payload),
            )
            db.execute(
                """DELETE FROM workspace_backups WHERE workspace_id=? AND id NOT IN
                   (SELECT id FROM workspace_backups WHERE workspace_id=? ORDER BY id DESC LIMIT ?)""",
                (key, key, BACKUP_LIMIT),
            )
        return self.list_backups(key)



def _row_values(row):
    return tuple(row.values()) if isinstance(row, dict) else tuple(row)


class _PgRow(dict):
    def __getitem__(self, key):
        return tuple(self.values())[key] if isinstance(key, int) else super().__getitem__(key)


def _pg_row(cursor):
    if cursor.description is None:
        return tuple
    names = tuple(col.name for col in cursor.description)
    return lambda values: _PgRow(zip(names, values))


class _PgConnection:
    # Все SQL-идентификаторы задаются приложением, пользовательские значения — только параметры.
    def __init__(self, connection):
        self.connection = connection

    def execute(self, sql, params=()):
        return self.connection.execute(sql.replace("?", "%s"), params)

    def executemany(self, sql, params):
        with self.connection.cursor() as cursor:
            cursor.executemany(sql.replace("?", "%s"), params)


def _postgres_schema():
    sql = SCHEMA.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
    sql = sql.replace("INTEGER", "BIGINT").replace(" REAL ", " DOUBLE PRECISION ").replace(" BLOB ", " BYTEA ")
    sql = sql.replace("site, machine, work, cost, date, volume, fuel, hours,",
                      ", ".join(f"{key} JSONB" for key in INPUT_FIELDS) + ",")
    return sql.replace("site, machine, work,", "site JSONB, machine JSONB, work JSONB,")


class PostgresStorage(Storage):
    backend = "PostgreSQL"

    def __init__(self, dsn):
        import psycopg

        self.dsn = dsn
        self.driver = psycopg
        with self._transaction(write=True) as db:
            for statement in _postgres_schema().split(";"):
                if statement.strip():
                    db.execute(statement)
        self._catalog_upgrade()

    @contextmanager
    def _transaction(self, *, write=False):
        with self.driver.connect(self.dsn, row_factory=_pg_row, connect_timeout=5, application_name="grader") as connection:
            db = _PgConnection(connection)
            if write:
                # Удерживается только в течение транзакции. Согласует импорт/удаление/перепроверку.
                db.execute("SELECT pg_advisory_xact_lock(1600472628)")
            else:
                db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY")
            yield db

    @staticmethod
    def _input_cell(value):
        from psycopg.types.json import Jsonb

        value = _cell(value)
        return Jsonb(value) if value is not None else None



def open_storage(path, dsn=None):
    if dsn:
        return PostgresStorage(dsn)
    return Storage(path, legacy=("workspace", "payload", lambda payload: payload))

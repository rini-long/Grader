"""Перенос SQLite-файла «Грейдера» в пустую базу PostgreSQL. Оригинал не меняется."""
from argparse import ArgumentParser
from contextlib import closing
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from storage import INPUT_FIELDS, SNAPSHOT_TABLES, PostgresStorage, open_storage


def migrate(source, dsn):
    source = Path(source).resolve(strict=True)
    if not source.is_file():
        raise ValueError('Нужно указать файл SQLite.')
    with TemporaryDirectory(prefix='grader-migrate-') as folder:
        copy = Path(folder) / 'input.sqlite3'
        with closing(sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)) as db, closing(sqlite3.connect(copy)) as target:
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {'workspace_settings', 'imports'}.issubset(tables) and 'workspace' not in tables:
                raise ValueError('Файл не является поддерживаемой базой «Грейдера».')
            db.backup(target)
        original = open_storage(copy)
        target = PostgresStorage(dsn)
        with original._transaction() as old, target._transaction(write=True) as new:
            if new.execute('SELECT 1 FROM workspace_settings LIMIT 1').fetchone():
                raise ValueError('Целевая база не пуста. Для переноса создайте новую базу PostgreSQL.')
            for table in ('workspace_settings', *SNAPSHOT_TABLES, 'workspace_backups'):
                query = old.execute(f'SELECT * FROM {table}')
                columns = tuple(col[0] for col in query.description)
                as_json = set(INPUT_FIELDS) if table in ('raw_rows', 'reference_rows') else set()
                values = (tuple(target._input_cell(r[k]) if k in as_json else r[k] for k in columns) for r in query)
                new.executemany(f"INSERT INTO {table} ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})", values)
            for table in ('imports', 'workspace_backups'):
                new.execute(f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), COALESCE(MAX(id), 1), MAX(id) IS NOT NULL) FROM {table}")
            return {kind: new.execute(f'SELECT COUNT(*) FROM {kind}').fetchone()[0]
                    for kind in ('workspace_settings', 'imports', 'clean_rows', 'workspace_backups')}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Путь к исходной SQLite-базе или скачанному снимку')
    parser.add_argument('--dsn', default=os.environ.get('DATABASE_URL'), help='Строка PostgreSQL. По умолчанию: DATABASE_URL')
    args = parser.parse_args()
    if not args.dsn:
        parser.error('Установите DATABASE_URL или укажите --dsn.')
    try:
        print('Перенос завершён:', migrate(args.source, args.dsn))
    except (ValueError, OSError, sqlite3.DatabaseError) as e:
        raise SystemExit(str(e)) from None

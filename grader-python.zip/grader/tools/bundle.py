"""Собрать автономный grader-one-file.py из исходников приложения."""
from argparse import ArgumentParser
import ast
from base64 import b64encode
from pathlib import Path
import textwrap

ROOT = Path(__file__).resolve().parents[1]
MODULES = ("engine", "analytics", "spreadsheets", "storage", "app")
TEXT_ASSETS = {
    "react/app.css": "text/css",
    "react/app.js": "text/javascript",
    "licenses.txt": "text/plain",
    "mark.svg": "image/svg+xml",
    "fonts/OFL.txt": "text/plain",
}
BINARY_ASSETS = {
    "fonts/onest-latin.woff2": "font/woff2",
    "fonts/onest-cyrillic.woff2": "font/woff2",
}


def without_local_imports(name):
    source = (ROOT / f"{name}.py").read_text(encoding="utf-8")
    removed = set()
    for node in ast.parse(source).body:
        local = isinstance(node, ast.ImportFrom) and node.module in MODULES
        if name == "app" and isinstance(node, ast.Assign) and any(
            isinstance(k, ast.Name) and k.id == "app" for k in node.targets
        ):
            # Вместо обычной точки входа подключаем встроенные ресурсы.
            return "\n".join(line for number, line in enumerate(source.splitlines(), 1)
                             if number < node.lineno and number not in removed).strip()
        if local:
            removed.update(range(node.lineno, node.end_lineno + 1))
    return "\n".join(line for number, line in enumerate(source.splitlines(), 1)
                     if number not in removed).strip()


def literal(value):
    for delimiter in ('"""', "'''"):
        if delimiter not in value and not value.endswith(("\\", delimiter[0])):
            return f"r{delimiter}{value}{delimiter}"
    return repr(value)


def build(output):
    parts = ['''#!/usr/bin/env python3
"""Грейдер 1.3: полное Flask-приложение в одном файле.

Python 3.11+. Установка: python -m pip install "Flask>=3.1,<4" "openpyxl>=3.1,<4" "rapidfuzz>=3.10,<4" "xlrd>=2.0.1,<3"
Запуск: python grader-one-file.py, затем открыть http://localhost:8000.
База по умолчанию: grader-local.sqlite3 рядом со скриптом. Можно указать GRADER_DATABASE и PORT.
Для PostgreSQL установите psycopg[binary] и задайте DATABASE_URL.
Собрано из исходников проекта скриптом grader/tools/bundle.py.
"""
from base64 import b64decode
from flask import abort
from jinja2 import DictLoader
''']
    for name in MODULES:
        parts.append(f"\n# ─── {name}.py ────────────────────────────────────────────────────\n\n{without_local_imports(name)}\n")
    parts.append("\n# ─── Интерфейс и локальные ресурсы ──────────────────────────────────\n\n")
    index = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    parts.append(f"_INDEX_HTML = {literal(index)}\n\n")
    parts.append("_TEXT_ASSETS = {\n")
    for filename, mime in TEXT_ASSETS.items():
        content = (ROOT / "static" / filename).read_text(encoding="utf-8")
        parts.append(f"    {filename!r}: ({mime!r}, {literal(content)}),\n")
    parts.append("}\n\n_BINARY_ASSETS = {\n")
    for filename, mime in BINARY_ASSETS.items():
        encoded = b64encode((ROOT / "static" / filename).read_bytes()).decode("ascii")
        content = "\n".join(f"        {line!r}" for line in textwrap.wrap(encoded, 100))
        parts.append(f"    {filename!r}: ({mime!r},\n{content}\n    ),\n")
    parts.append('''}


def serve_embedded_asset(filename):
    if filename in _TEXT_ASSETS:
        mimetype, text = _TEXT_ASSETS[filename]
        body = text.encode("utf-8")
    elif filename in _BINARY_ASSETS:
        mimetype, encoded = _BINARY_ASSETS[filename]
        body = b64decode(encoded)
    else:
        abort(404)
    return send_file(BytesIO(body), mimetype=mimetype, download_name=filename.rsplit("/", 1)[-1])


app = create_app({
    "DATABASE": os.environ.get("GRADER_DATABASE", str(Path(__file__).with_name("grader-local.sqlite3"))),
    "STANDALONE": True,
})
app.jinja_loader = DictLoader({"index.html": _INDEX_HTML})
app.view_functions["static"] = serve_embedded_asset

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
''')
    code = "\n".join(parts)
    compile(code, str(output), "exec")
    output.write_text(code, encoding="utf-8")


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", default=ROOT.parent / "grader-one-file.py", type=Path)
    build(parser.parse_args().output)

module.exports = { content: ['./src/**/*.{js,jsx}'], corePlugins: { preflight: false }, theme: { extend: {} } };

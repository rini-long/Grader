import { useEffect, useMemo, useState } from 'react';

export const metricLabels = { volume: 'Объём работ', fuel: 'Расход топлива', hours: 'Моточасы', cost: 'Затраты', distance: 'Километраж', plan_hours: 'Плановые моточасы' };
export const units = { volume: 'м³', fuel: 'л', hours: 'ч', cost: '₽', distance: 'км', plan_hours: 'ч' };
export const statuses = { completed: 'Завершено', in_progress: 'В процессе', attention: 'Требует проверки', verified: 'Проверено' };
const fmt = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
const shortFmt = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1, notation: 'compact' });
const monthNames = 'Январь Февраль Март Апрель Май Июнь Июль Август Сентябрь Октябрь Ноябрь Декабрь'.split(' ');
const shortMonths = 'Янв Фев Мар Апр Май Июн Июл Авг Сен Окт Ноя Дек'.split(' ');
export const number = v => fmt.format(v);
export const shortNumber = v => shortFmt.format(v);
export const amount = v => v == null ? '—' : number(v / 100);
export const measure = (value, key) => value == null ? '—' : `${amount(value)} ${units[key]}`;
export function monthText(iso, brief = false, year = true) {
  if (!iso) return 'Весь период';
  const [y, m] = iso.split('-');
  return `${(brief ? shortMonths : monthNames)[+m - 1]}${year ? ` ${y}` : ''}`;
}
export const dateText = iso => !iso ? 'Без даты' : iso.length === 10 ? iso.split('-').reverse().join('.') : monthText(iso);
export const stamp = iso => iso ? new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(iso)) : '—';
export const filenameSize = n => n >= 1024 ** 2 ? `${number(n / 1024 ** 2)} МБ` : `${number(n / 1024)} КБ`;
export function periodRange(months) {
  if (months.length < 2) return 'Весь журнал';
  const first = months[0], last = months.at(-1);
  return `${monthText(first, true, first.slice(0, 4) !== last.slice(0, 4))} — ${monthText(last, true)}`;
}
export function qs(values = {}) {
  const out = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) if (value !== '' && value != null) out.set(key, value);
  return out.size ? `?${out}` : '';
}
export function workspaceKey() {
  const create = () => Array.from(crypto.getRandomValues(new Uint8Array(20)), n => n.toString(16).padStart(2, '0')).join('');
  try {
    const name = 'grader-workspace-v1';
    const existing = localStorage.getItem(name);
    if (/^[a-f0-9]{40}$/.test(existing || '')) return existing;
    const key = create();
    localStorage.setItem(name, key);
    return key;
  } catch { return create(); }
}
const key = workspaceKey();
export async function api(url, options = {}, raw = false) {
  let res;
  try { res = await fetch(url, { ...options, headers: { ...options.headers, 'X-Workspace': key } }); }
  catch (err) {
    if (err.name === 'AbortError') throw err;
    throw new Error('Нет связи с сервером. Попробуйте ещё раз.');
  }
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.error || 'Не удалось выполнить запрос.');
  }
  return raw ? res : res.json();
}
export async function download(url, fallback) {
  const response = await api(url, {}, true);
  const file = URL.createObjectURL(await response.blob());
  const target = document.createElement('a');
  const disposition = response.headers.get('Content-Disposition') || '';
  const name = disposition.match(/filename="?([\w.\-]+)"?/i)?.[1];
  target.href = file;
  target.download = name || fallback;
  document.body.append(target);
  target.click();
  target.remove();
  setTimeout(() => URL.revokeObjectURL(file), 30_000);
}
export function useRequest(url, revision = 0) {
  const [out, set] = useState({ url: '', revision: -1, data: null, error: null });
  const [retry, again] = useState(0);
  useEffect(() => {
    if (!url) return;
    const request = new AbortController();
    set(prev => ({ ...prev, error: null, loading: true }));
    api(url, { signal: request.signal }).then(data => {
      if (!request.signal.aborted) set({ data, error: null, url, revision, loading: false });
    }).catch(error => {
      if (!request.signal.aborted) set({ data: null, error: error.message, url, revision, loading: false });
    });
    return () => request.abort();
  }, [url, revision, retry]);
  return useMemo(() => out.url === url && out.revision === revision ? { ...out, retry: () => again(x => x + 1) }
    : { data: null, error: null, loading: !!url, retry: () => again(x => x + 1) }, [url, out, revision]);
}
export const recordLink = (row, journal) => `#record/${row}${qs({ journal: journal ?? 'demo' })}`;
export const siteLink = name => `#site/${encodeURIComponent(name)}`;
export function readRoute() {
  const raw = (location.hash.slice(1) || 'overview');
  const separator = raw.indexOf('?');
  const address = separator < 0 ? raw : raw.slice(0, separator);
  const args = new URLSearchParams(separator < 0 ? '' : raw.slice(separator + 1));
  const slash = address.indexOf('/');
  let detail = address.slice(slash < 0 ? address.length : slash + 1);
  try { detail = decodeURIComponent(detail); } catch { detail = ''; }
  let view = address.slice(0, slash < 0 ? address.length : slash);
  if (!['overview', 'history', 'results', 'charts', 'backup', 'settings', 'about', 'import', 'errors', 'metric', 'site', 'record'].includes(view)) view = 'overview';
  return { view, detail, args };
}

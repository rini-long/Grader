import React, { useEffect, useState } from 'react';
import { AlertCircle, ArrowLeft, CalendarDays, Check, ChevronRight, ClipboardCheck, Database, Download, FileSpreadsheet, FolderOpen, History, Info, MapPin, Play, Search, Trash2, Upload, X } from 'lucide-react';
import { BusyIcon, Delta, DownloadButton, Empty, PageHead, Pagination, RequestBody, StatStrip, Status, Table, journalColumns } from './components';
import { Trend } from './charts';
import { metricIcons } from './dashboard';
import { api, dateText, filenameSize, measure, metricLabels, monthText, number, qs, recordLink, siteLink, stamp, units, useRequest } from './lib';

const sections = { clean: 'Проверенные записи', site: 'По участкам', machine: 'По машинам', work: 'По видам работ' };
const statMetrics = ['volume', 'hours', 'cost'];
const defaultSettings = { threshold: .8, hint_min: .6, split_mode: 'equal' };

function Back({ href, children }) { return <a className="text-link back-link" href={href}><ArrowLeft size={15}/>{children}</a>; }
function ScopeNote({ scope }) {
  return <div className="scope-note"><CalendarDays size={15}/><span>{monthText(scope.state.period)} · {scope.state.source === 'demo' ? 'Демо-данные' : scope.state.files.raw}</span>
    {scope.state.equipment_type && <button className="filter-chip" type="button" onClick={() => scope.setFilter({ equipment: '' })} aria-label={`Сбросить фильтр ${scope.state.equipment_type}`}>{scope.state.equipment_type}<X size={13}/></button>}</div>;
}
function SearchBox({ value, onChange }) {
  return <label className="search"><Search size={15}/><input type="search" value={value} aria-label="Поиск по таблице" placeholder="Поиск по таблице" maxLength={160} onChange={e => onChange(e.target.value)}/></label>;
}
export function Reports({ scope, kind = 'clean', inHistory = false }) {
  const { state, params, notify } = scope;
  const errors = kind === 'errors';
  const [text, setText] = useState(''), [query, setQuery] = useState(''), [page, setPage] = useState(1);
  useEffect(() => { const timeout = setTimeout(() => { setQuery(text.trim()); setPage(1); }, 160); return () => clearTimeout(timeout); }, [text]);
  const url = `/api/table${qs({ ...params, kind, q: query, page })}`;
  const request = useRequest(url, state.import_id || 0);
  const columns = errors ? [['row', 'Строка', r => <a className="table-link" href={recordLink(r.row, state.import_id)}>№ {r.row}</a>],
    ['raw', 'Исходные данные'], ['issue', 'Причина'], ['hint', 'Подсказка']]
    : kind === 'clean' ? journalColumns(state.import_id) : [
      ['name', kind === 'site' ? 'Участок' : kind === 'machine' ? 'Машина' : 'Вид работы', r => kind === 'site' ? <a className="table-link" href={siteLink(r.name)}>{r.name}</a> : r.name],
      ...(kind === 'site' ? [['distance', 'Километраж', r => measure(r.distance, 'distance'), true], ['volume', 'Объём', r => measure(r.volume, 'volume'), true]] : []),
      ['count', 'Записей', r => number(r.count), true], ['cost', 'Затраты', r => measure(r.cost, 'cost'), true],
    ];
  return <section>
    <PageHead eyebrow={inHistory ? 'Хранилище данных' : errors ? 'Контроль данных' : 'Данные и сводки'} title={inHistory ? 'База данных' : errors ? 'Ошибки' : 'Отчёты'}
      description={errors ? 'Строки, которые необходимо проверить в исходном журнале.' : inHistory ? 'Журнал работ и карточки записей текущей загрузки.' : 'Детализация дорожных работ за выбранный период.'}>
      {!errors && !inHistory && <a className="btn secondary" href="#errors"><AlertCircle size={16}/>Ошибки{state.all_errors > 0 && <span className="count-badge">{number(state.all_errors)}</span>}</a>}
      {errors ? <a className="btn primary" href="#import"><Upload size={16}/>Загрузить исправления</a>
        : <DownloadButton url={`/api/report${qs(params)}`} notify={notify}/>}
    </PageHead>
    <ScopeNote scope={scope}/>
    {errors && state.equipment_type && <p className="notice">Проверка показывает ошибки всех машин за период: часть исходных названий не удалось сопоставить.</p>}
    {!errors && <StatStrip entries={statMetrics.map(key => [metricLabels[key], measure(state.clean_rows ? state.metrics[key] : null, key), metricIcons[key]])}/>}
    <article className="surface table-panel"><div className="table-toolbar">
      {inHistory ? <HistoryTabs records/> : errors ? <h2>Журнал проверки</h2> : <nav className="table-tabs" aria-label="Виды отчётов">{Object.entries(sections).map(([k, title]) => <a className={k === kind ? 'active' : ''} aria-current={k === kind ? 'page' : undefined} key={k} href={k === 'clean' ? '#results' : `#results/${k}`}>{title}</a>)}</nav>}
      <SearchBox value={text} onChange={setText}/>
    </div><RequestBody request={request}>{data => <><Table columns={columns} rows={data.rows} label={errors ? 'Ошибки проверки' : 'Журнал и сводки'} empty={query ? 'По этому запросу ничего не найдено' : errors ? 'За период ошибок нет' : undefined}/><Pagination data={data} onPage={setPage}/></>}</RequestBody></article>
  </section>;
}

function HistoryTabs({ records = false }) {
  return <nav className="table-tabs" aria-label="Разделы базы данных"><a href="#history" className={!records ? 'active' : ''}>История загрузок</a><a href="#history/records" className={records ? 'active' : ''}>Журнал работ</a></nav>;
}
export function Archive({ scope }) {
  const { state, notify, apply } = scope;
  const [page, setPage] = useState(1), [revision, setRevision] = useState(0), [busy, setBusy] = useState(false), [pending, setPending] = useState(null);
  const request = useRequest(`/api/imports${qs({ page })}`, `${state.import_id}/${state.storage.imports_count}/${revision}`);
  async function open(item) {
    if (busy) return;
    setBusy(true);
    try { const data = await api(`/api/imports/${item.id}/open`, { method: 'POST' }); apply(data); location.hash = '#history/records'; notify('Журнал открыт.'); }
    catch (error) { notify(error.message, true); }
    finally { setBusy(false); }
  }
  async function remove() {
    if (busy || !pending) return;
    setBusy(true);
    try {
      const data = await api(`/api/imports/${pending.id}`, { method: 'DELETE' }); apply(data);
      setPending(null); setRevision(v => v + 1); notify('Журнал удалён.');
    } catch (error) { notify(error.message, true); }
    finally { setBusy(false); }
  }
  const columns = [
    ['raw_file', 'Журнал и справочник', row => <div className="table-lines"><b>{row.raw_file}</b><small>{row.ref_file}</small>{!!row.active && <span className="tag live">Текущий журнал</span>}</div>],
    ['created_at', 'Дата загрузки', row => stamp(row.created_at)], ['raw_count', 'Строк', row => number(row.raw_count), true],
    ['error_count', 'Ошибки', row => number(row.error_count), true],
    ['actions', 'Действия', row => <div className="table-actions">{row.active ? <a href="#history/records" className="btn small secondary">Журнал<ChevronRight size={13}/></a> : <button type="button" className="btn small secondary" onClick={() => open(row)} disabled={busy}>Открыть<ChevronRight size={13}/></button>}
      <DownloadButton iconOnly url={`/api/imports/${row.id}/report`} caption="Скачать полный отчёт" notify={notify}/>
      <button className="icon-btn danger-ghost" type="button" aria-label={`Удалить ${row.raw_file}`} onClick={() => setPending(row)} disabled={busy}><Trash2 size={15}/></button></div>],
  ];
  return <section><PageHead eyebrow="Хранилище данных" title="База данных" description="Открывайте и выгружайте ранее проверенные журналы."><a className="btn primary" href="#import"><Upload size={16}/>Новая загрузка</a></PageHead>
    <StatStrip entries={[["Журналов в базе", number(state.storage.imports_count), Database], ["Строк в журналах", number(state.storage.rows_count), ClipboardCheck], ["Хранилище", state.database, FolderOpen]]}/>
    <article className="surface table-panel"><div className="table-toolbar"><HistoryTabs/><span className="tag"><i/>{state.database}</span></div>
      <RequestBody request={request}>{data => <>{data.total ? <><Table columns={columns} rows={data.rows} rowKey={r => r.id} label="История загрузок"/>
        <Pagination data={{ ...data, found: data.total, start: (data.page - 1) * 10 + 1, end: Math.min(data.page * 10, data.total) }} onPage={setPage}/></> : <Empty title="История пока пуста" text="Загрузите журнал и справочник; проверенные данные появятся в этом разделе." icon={Database}><a href="#import" className="btn secondary"><Upload size={15}/>Загрузить Excel</a></Empty>}</>}</RequestBody>
    </article>
    {!!pending && <Confirm title="Удалить журнал?" text={`«${pending.raw_file}» исчезнет из истории. Уже созданные копии базы не изменятся.`} action="Удалить" busy={busy} onCancel={() => setPending(null)} onConfirm={remove} danger/>}
  </section>;
}
function Confirm({ title, text, action, busy, onCancel, onConfirm, danger }) {
  const [ref, setRef] = useState(null);
  useEffect(() => { if (ref && !ref.open) ref.showModal(); }, [ref]);
  return <dialog className="modal" ref={setRef} onCancel={e => { e.preventDefault(); if (!busy) onCancel(); }}><h2>{title}</h2><p>{text}</p><div className="flex justify-end gap-2"><button type="button" className="btn secondary" disabled={busy} onClick={onCancel}>Отмена</button><button type="button" className={`btn ${danger ? 'danger' : 'primary'}`} disabled={busy} onClick={onConfirm}>{busy && <BusyIcon/>}{action}</button></div></dialog>;
}

export function Metric({ scope, name }) {
  const { state, params, notify } = scope;
  const [page, setPage] = useState(1);
  const request = useRequest(`/api/metric/${encodeURIComponent(name)}${qs({ ...params, page })}`, state.import_id || 0);
  const caps = metricLabels[name] || 'Показатель';
  return <section><Back href="#overview">К сводке работ</Back><PageHead title={caps} eyebrow="Детализация показателя" description="Из проверенных строк журнала за выбранный период.">
    <DownloadButton url={`/api/report/metric/${encodeURIComponent(name)}${qs(params)}`} disabled={request.data?.value == null} notify={notify}/></PageHead><ScopeNote scope={scope}/>
    <RequestBody request={request}>{data => <>
      <div className="detail-grid"><article className="surface detail-lead"><p className="eyebrow">Итого за период</p><strong>{measure(data.value, name)}</strong><Delta change={data.change} metric={name}/><div className="detail-breakdown"><h2>Вклад участков</h2>{data.by_site.length ? data.by_site.map(site => <a key={site.name} href={siteLink(site.name)}><span>{site.name}</span><b>{measure(site[name], name)}</b></a>) : <p>Нет значений этого показателя.</p>}</div></article><Trend series={data.series} metric={name}/></div>
      <article className="surface table-panel"><div className="table-toolbar"><h2>Записи журнала</h2><span className="tag">{number(data.total)} записей</span></div><Table columns={journalColumns(data.journal, name)} rows={data.rows}/><Pagination data={data} onPage={setPage}/></article>
    </>}</RequestBody>
  </section>;
}

export function SiteDetail({ scope, name }) {
  const { state, params, notify } = scope;
  const [page, setPage] = useState(1);
  const request = useRequest(`/api/site${qs({ ...params, name, page })}`, state.import_id || 0);
  return <section><Back href="#overview">К сводке работ</Back><PageHead title={name} eyebrow="Карточка участка" description="Фактические показатели и история работ по текущему журналу.">
    <DownloadButton url={`/api/report/sites${qs({ ...params, site: name })}`} notify={notify} disabled={!request.data?.total}/></PageHead><ScopeNote scope={scope}/>
    <RequestBody request={request}>{data => <>
      <StatStrip entries={['distance', 'volume', 'cost'].map(key => [metricLabels[key], measure(data.totals[key], key), metricIcons[key]])}/>
      <article className="surface table-panel"><div className="table-toolbar"><h2>История работ</h2><span className="tag">{number(data.total)} записей</span></div><Table columns={journalColumns(data.journal)} rows={data.rows}/><Pagination data={data} onPage={setPage}/></article>
    </>}</RequestBody>
  </section>;
}

export function Record({ row, journal }) {
  const request = useRequest(`/api/records/${encodeURIComponent(row)}${qs({ journal })}`);
  return <section><Back href="#history/records">К журналу работ</Back><PageHead title={`Запись № ${row}`} eyebrow="Карточка путевого листа" description="Данные исходной строки и результат проверки."/>
    <RequestBody request={request}>{data => {
      const first = data.checked[0];
      return <>
        <div className="surface record-details"><div className="table-toolbar"><h2>{data.raw.machine || 'Машина не указана'}</h2>{first ? <Status code={first.status}/> : <span className="tag warning">Ошибка проверки</span>}</div>
          <dl className="record-grid">{[['Дата', first?.date ? dateText(first.date) : data.raw.date], ['Журнал', data.files.raw], ['Участок (исходный)', data.raw.site], ['Сотрудник', data.raw.employee], ['Вид работы (исходный)', data.raw.work], ['Тип техники', data.checked.length === 1 ? first.equipment_type : null]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value ?? '—'}</dd></div>)}</dl>
          {data.error && <p className="notice danger-note"><AlertCircle size={17}/><span>{data.error.issue} <small>{data.error.hint}</small></span></p>}
        </div>
        {!!data.checked.length && <><StatStrip entries={['distance', 'volume', 'cost', 'fuel', 'hours', 'plan_hours'].map(key => [metricLabels[key], measure(data.totals[key], key), metricIcons[key]])}/>
          <article className="surface table-panel"><div className="table-toolbar"><h2>Результат проверки</h2></div><Table columns={journalColumns(data.journal).filter(([key]) => key !== 'row')} rows={data.checked}/></article></>}
      </>;
    }}</RequestBody>
  </section>;
}

function FileSlot({ id, title, note, file, select }) {
  const [drag, setDrag] = useState(false);
  return <div><div className="slot-head"><span className="glyph"><FileSpreadsheet size={18}/></span><div><h3>{title}</h3><p>{note}</p></div></div>
    <label className={`dropzone ${drag ? 'drag' : ''} ${file ? 'with-file' : ''}`} onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); select(e.dataTransfer.files[0] || null); }}>
      <input key={file === null ? 'empty' : 'selected'} id={id} type="file" accept=".xls,.xlsx" className="sr-only" onChange={e => { if (e.target.files[0]) select(e.target.files[0]); }}/><Upload size={24}/><b>{file ? file.name : 'Выбрать Excel-файл'}</b><span>{file ? filenameSize(file.size) : 'или перетащите сюда · XLS / XLSX'}</span>
    </label>{file && <button type="button" className="text-link clear-file" onClick={() => select(null)}><X size={13}/>Убрать файл</button>}
  </div>;
}
export function Templates({ dense = false }) {
  return <div className={`template-list ${dense ? 'dense' : ''}`} id="excel-templates"><div><h2>Шаблоны Excel</h2><p>Заголовки — в первой строке. Используется первый лист.</p></div><div className="template-links">
    <a className="btn secondary small" href="/files/template-works.xlsx"><Download size={14}/>Пустой журнал</a>
    <a className="btn secondary small" href="/files/template-reference.xlsx"><Download size={14}/>Пустой справочник</a>
    <a className="btn secondary small" href="/files/demo-works.xlsx"><Download size={14}/>Пример журнала</a>
    <a className="btn secondary small" href="/files/demo-reference.xlsx"><Download size={14}/>Пример справочника</a>
  </div></div>;
}
export function Import({ scope }) {
  const { state, apply, notify } = scope;
  const [raw, setRaw] = useState(null), [ref, setRef] = useState(null), [busy, setBusy] = useState(false), [message, setMessage] = useState(''), [confirm, setConfirm] = useState(false);
  async function upload(event) {
    event.preventDefault();
    if (!raw || !ref || busy) return;
    setMessage('');
    for (const file of [raw, ref]) {
      if (!/\.xlsx?$/i.test(file.name)) { setMessage('Выберите файл .xls или .xlsx.'); return; }
      if (file.size > 10 * 1024 ** 2) { setMessage('Размер одной книги не должен превышать 10 МБ.'); return; }
    }
    setBusy(true);
    const body = new FormData(); body.append('raw', raw); body.append('ref', ref);
    try { const data = await api('/api/import', { method: 'POST', body }); apply(data); location.hash = '#overview'; notify('Журнал проверен и сохранён в базе.'); }
    catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  }
  async function demo() {
    setBusy(true);
    try { const data = await api('/api/demo', { method: 'POST' }); apply(data); setConfirm(false); location.hash = '#overview'; notify('Открыт демонстрационный набор.'); }
    catch (error) { setConfirm(false); setMessage(error.message); }
    finally { setBusy(false); }
  }
  return <section><PageHead eyebrow="Excel → журнал работ" title="Загрузка данных" description="Сопоставьте журнал работ со справочником и сохраните результат в базе."><button type="button" className="btn secondary" disabled={busy} onClick={() => state.source === 'import' ? setConfirm(true) : demo()}><Play size={15}/>Открыть демо</button></PageHead>
    <form className="surface form-panel" onSubmit={upload}><div className="file-grid"><FileSlot id="work-file" title="Журнал работ" note="Участок, машина, вид работы, затраты" file={raw} select={setRaw}/><FileSlot id="reference-file" title="Справочник" note="Участок, машина, вид работ, тип техники (по желанию)" file={ref} select={setRef}/></div>
    {message && <p className="notice danger-note" role="alert">{message}</p>}
    <div className="form-footer"><span>До 10 МБ на файл</span><button className="btn primary" disabled={!raw || !ref || busy} type="submit">{busy ? <BusyIcon/> : <Check size={16}/>} {busy ? 'Проверяем…' : 'Обработать файлы'}</button></div></form>
    <div className="surface form-panel template-panel"><Templates/><p className="subtle">Дополнительные колонки журнала: дата, объём, расход топлива, моточасы, плановые моточасы, километраж, сотрудник и статус.</p></div>
    {confirm && <Confirm title="Открыть демо-данные?" text="Текущий журнал останется в истории загрузок." action="Открыть демо" busy={busy} onConfirm={demo} onCancel={() => setConfirm(false)}/>}
  </section>;
}

export function CopyPage({ scope }) {
  const { state, createCopy, copyBusy, notify } = scope;
  const request = useRequest('/api/backups', state.backup.latest?.id || 0);
  const columns = [ ['created_at','Дата и время', r => <time dateTime={r.created_at}>{stamp(r.created_at)}</time>], ['import_count','Журналов', r => number(r.import_count), true], ['size_bytes','Размер', r => filenameSize(r.size_bytes), true],
    ['file','Файл', r => <DownloadButton className="small" url={`/api/backups/${r.id}/file`} file={`grader-backup-${r.id}.sqlite3`} caption="Скачать копию" notify={notify}/>] ];
  return <section><PageHead eyebrow="Сохранность данных" title="Резервное копирование" description="Снимки журналов, результатов и настроек этой рабочей области."><button type="button" className="btn green" disabled={copyBusy} aria-busy={copyBusy} onClick={createCopy}>{copyBusy ? <BusyIcon/> : <History size={17}/>} {copyBusy ? 'Создаём…' : 'Создать копию'}</button></PageHead>
    <article className="surface table-panel"><header className="table-toolbar"><div><h2>Сохранённые копии</h2><p>Хранятся пять последних снимков. Скачивайте важные копии отдельно.</p></div><span className="tag">SQLite · переносимый файл</span></header>
      <RequestBody request={request}>{data => data.rows.length ? <Table columns={columns} rows={data.rows} rowKey={r => r.id} label="Резервные копии"/> : <Empty title="Копий пока нет" text="Нажмите «Создать копию», чтобы сохранить снимок базы." icon={History}/>}</RequestBody></article>
    <div className="surface help-band"><span className="glyph"><Info size={19}/></span><div><h2>Что входит в копию</h2><p>Все загрузки этого браузера, справочники, результаты проверки и настройки. Фильтры отчёта не ограничивают копию. Снимок можно открыть в SQLite или перенести в PostgreSQL по инструкции проекта.</p></div></div>
  </section>;
}

export function Settings({ scope }) {
  const { state, apply, params, notify } = scope;
  const [form, setForm] = useState(state.settings), [busy, setBusy] = useState(false), [message, setMessage] = useState('');
  useEffect(() => { setForm(state.settings); }, [state.import_id, state.settings.threshold, state.settings.hint_min, state.settings.split_mode]);
  async function save(e) {
    e.preventDefault(); setBusy(true); setMessage('');
    try { const data = await api(`/api/settings${qs(params)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) }); apply(data); notify('Настройки сохранены. Журнал проверен заново.'); }
    catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  }
  return <section><PageHead eyebrow="Правила проверки" title="Настройки" description="Управляйте сопоставлением Excel-строк со справочником."/><form className="surface form-panel settings-panel" onSubmit={save}>
    {[['threshold','Порог автосопоставления','Степень сходства для автоматического выбора.'], ['hint_min','Порог подсказки','Минимальное сходство для варианта в отчёте об ошибках.']].map(([key, label, text]) => <div className="setting-row" key={key}><div><label htmlFor={key}>{label}</label><p>{text}</p></div><div className="range"><input type="range" id={key} min={0} max={key === 'hint_min' ? Math.round(form.threshold * 100) : 100} value={Math.round(form[key] * 100)} onChange={e => { const v = +e.target.value / 100; setForm(s => ({ ...s, [key]: v, ...(key === 'threshold' && s.hint_min > v ? { hint_min: v } : {}) })); }}/><output htmlFor={key}>{Math.round(form[key] * 100)}%</output></div></div>)}
    <fieldset><legend>Несколько значений в одной строке</legend><div className="radio-grid">{[['equal','Распределить поровну','Разделить затраты, часы, объём и расстояние без потери суммы.'], ['flag','Отправить на проверку','Пометить строку и предложить исправление.']].map(([k, title, text]) => <label className="radio-card" key={k}><input type="radio" name="split_mode" checked={k === form.split_mode} onChange={() => setForm(f => ({ ...f, split_mode: k }))}/><span><b>{title}</b><small>{text}</small></span></label>)}</div></fieldset>
    {message && <p className="notice danger-note" role="alert">{message}</p>}<div className="form-footer"><button type="button" className="btn secondary" onClick={() => { setForm(defaultSettings); setMessage(''); }} disabled={busy}>По умолчанию</button><button className="btn primary" type="submit" disabled={busy}>{busy ? <BusyIcon/> : <Check size={16}/>}Сохранить настройки</button></div>
  </form></section>;
}
export function About({ database }) {
  return <section><PageHead eyebrow="Информация" title="О программе" description="Грейдер · учёт и аналитика дорожных работ"/>
    <div className="surface help-band"><span className="glyph"><Info size={20}/></span><div><h2>Грейдер 1.3</h2><p>Проверяет Excel-журналы по справочнику, сопоставляет названия и собирает рабочие отчёты. Технологии: React, Chart.js, Tailwind CSS, Python/Flask и {database}.</p></div></div>
    <div className="surface form-panel template-panel"><Templates/><p className="subtle">Значения показателей и история зависят от загруженных книг. Демо — учебный набор, а не фактическая статистика вашей организации.</p></div>
  </section>;
}

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Chart, CategoryScale, LinearScale, LineController, LineElement, PointElement, DoughnutController, ArcElement, Filler, Tooltip } from 'chart.js';
import { ArrowUpRight, ChartNoAxesCombined, PieChart } from 'lucide-react';
import { amount, measure, metricLabels, monthText, number, shortNumber, units } from './lib';

Chart.register(CategoryScale, LinearScale, LineController, LineElement, PointElement, DoughnutController, ArcElement, Filler, Tooltip);
Chart.defaults.font.family = 'Onest, system-ui, sans-serif';
const tones = { volume: '#4789bb', cost: '#d0a044', fuel: '#5199ac', hours: '#6781b3' };
const legendTones = { ...tones, volume: '#9acff1', cost: '#f1d385' };
const palette = ['#99c9ed', '#e9cb82', '#cee7d8', '#80a5d1', '#ecc7ae', '#85c8bf', '#d7d9f0', '#ccd9df'];
const tooltip = { backgroundColor: '#233f52', padding: 11, titleFont: { size: 12 }, bodyFont: { size: 12 }, cornerRadius: 9, displayColors: true, boxPadding: 4 };
const plotField = {
  id: 'grader-plot-field',
  beforeDraw(chart) {
    const a = chart.chartArea;
    if (!a || a.right <= a.left || a.bottom <= a.top) return;
    const { ctx } = chart;
    const fill = ctx.createLinearGradient(a.left, a.top, a.left, a.bottom);
    fill.addColorStop(0, '#b4d5d5'); fill.addColorStop(1, '#accdce');
    ctx.save(); ctx.fillStyle = fill; ctx.fillRect(a.left, a.top, a.right - a.left, a.bottom - a.top); ctx.restore();
  },
};

export function Trend({ series, undated = 0, metric }) {
  const canvas = useRef(null), chartRef = useRef(null), selected = useRef(-1);
  const [lines, setLines] = useState({ volume: true, cost: true });
  const [focusLabel, setFocusLabel] = useState('');
  const keys = metric ? [metric] : ['volume', 'cost'];
  const available = keys.filter(key => series.some(point => point[key] != null));
  const visible = available.filter(key => metric || lines[key]);
  const optionsKey = visible.join(',');
  const hasChart = visible.length && series.length;
  useEffect(() => {
    if (!canvas.current || !hasChart) return;
    const active = optionsKey.split(',');
    const yearLabels = series[0].month.slice(0, 4) !== series.at(-1).month.slice(0, 4);
    const axes = Object.fromEntries(active.map((key, i) => [key, {
      type: 'linear', position: key === 'cost' && !metric ? 'right' : 'left', beginAtZero: true,
      ticks: { color: '#effafa', font: { size: 10 }, count: 5, maxTicksLimit: 5, padding: 6, callback: val => shortNumber(val) },
      title: { display: true, text: units[key], color: '#f0fafb', font: { size: 10, weight: '600' }, padding: 2 },
      grid: { drawOnChartArea: i === 0, color: '#5d8c94aa', tickColor: '#d9eeee77' },
      border: { color: '#e1f0ef99' },
    }]));
    const chart = new Chart(canvas.current, {
      type: 'line', plugins: [plotField],
      data: {
        labels: series.map(p => monthText(p.month, true, yearLabels)),
        datasets: active.map(key => ({
          label: metricLabels[key], data: series.map(row => row[key] == null ? null : row[key] / 100), yAxisID: key,
          borderColor: tones[key], backgroundColor: '#5798c622', borderWidth: 3, tension: 0,
          spanGaps: false, fill: key === 'volume', pointRadius: series.length > 48 ? 1.5 : 3.7,
          pointHoverRadius: 5.7, pointBorderWidth: 1.2, pointBorderColor: '#e4f1f0', pointBackgroundColor: tones[key],
        })),
      },
      options: {
        animation: false, maintainAspectRatio: false, responsive: true, interaction: { mode: 'index', intersect: false },
        layout: { padding: { top: 6, right: 3, bottom: 1, left: 3 } },
        scales: { x: { ticks: { color: '#f4fbfb', maxRotation: 0, font: { size: 10 }, maxTicksLimit: 9 },
          grid: { color: '#6c9fa29a', tickColor: '#b4d5d5' }, border: { color: '#e1f0ef99' } }, ...axes },
        plugins: { tooltip: { ...tooltip, callbacks: {
          title: items => monthText(series[items[0].dataIndex].month),
          label: item => `${item.dataset.label}: ${number(item.parsed.y)} ${units[item.dataset.yAxisID]}`,
        } } },
      },
    });
    chartRef.current = chart; selected.current = -1;
    return () => { chart.destroy(); chartRef.current = null; };
  }, [series, optionsKey, metric, hasChart]);
  function keyboard(event) {
    const chart = chartRef.current;
    if (!chart || !['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Escape'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === 'Escape') {
      chart.setActiveElements([]); chart.tooltip.setActiveElements([], { x: 0, y: 0 }); chart.update('none'); setFocusLabel(''); return;
    }
    selected.current = event.key === 'Home' ? 0 : event.key === 'End' ? series.length - 1
      : Math.max(0, Math.min(series.length - 1, selected.current + (event.key === 'ArrowLeft' ? -1 : 1)));
    const index = selected.current;
    const active = chart.data.datasets.flatMap((d, datasetIndex) => d.data[index] == null ? [] : [{ datasetIndex, index }]);
    const point = active.length ? chart.getDatasetMeta(active[0].datasetIndex).data[index] : { x: 0, y: 0 };
    chart.setActiveElements(active); chart.tooltip.setActiveElements(active, { x: point.x, y: point.y }); chart.update('none');
    setFocusLabel(`${monthText(series[index].month)}. ${visible.map(k => `${metricLabels[k]} ${measure(series[index][k], k)}`).join('. ')}`);
  }
  return <article className="chart-panel trend-panel" aria-label={metric ? `Динамика: ${metricLabels[metric]}` : 'Динамика работ'}>
    <div className="chart-head">
      <div><h2>{metric ? 'По месяцам' : 'Динамика работ'}</h2><p>{metric ? metricLabels[metric] : available.includes('volume') ? 'Объём и затраты по месяцам' : 'Показатели по месяцам'}</p></div>
      {!metric && <div className="chart-legend" aria-label="Ряды графика">{available.map(key => <button type="button" key={key} aria-pressed={lines[key]} onClick={() => setLines(s => ({ ...s, [key]: !s[key] }))}><i style={{ background: legendTones[key] }} />{key === 'volume' ? 'Объём' : 'Затраты'}</button>)}</div>}
    </div>
    {hasChart ? <div className="trend-canvas"><canvas ref={canvas} role="img" tabIndex={0} aria-label="Точные значения по месяцам. Используйте стрелки влево и вправо." onKeyDown={keyboard} /><span className="sr-only" aria-live="polite">{focusLabel}</span></div>
      : <div className="chart-empty"><ChartNoAxesCombined /><strong>{available.length ? 'Линии скрыты' : 'Нет данных за период'}</strong><span>{available.length ? 'Выберите ряд в легенде.' : 'Для графика нужны проверенные записи с датой.'}</span></div>}
    {!!undated && <p className="chart-note">Без даты: {number(undated)}. Эти строки учтены в итогах, но не на графике.</p>}
  </article>;
}

export function Workload({ load, filter, onFilter }) {
  const canvas = useRef(null), chartRef = useRef(null), handler = useRef(onFilter);
  handler.current = onFilter;
  const [index, setIndex] = useState(null);
  const items = load.items;
  const colors = useMemo(() => items.map((item, i) => filter && filter !== item.name ? `${palette[i % palette.length]}7a` : palette[i % palette.length]), [items, filter]);
  useEffect(() => {
    setIndex(null);
    if (!items.length || !canvas.current) return;
    const chart = new Chart(canvas.current, {
      type: 'doughnut',
      data: { labels: items.map(i => i.name), datasets: [{ data: items.map(i => i.value), backgroundColor: colors,
        borderColor: '#5d898e', borderWidth: 2, hoverOffset: 6, borderRadius: 2 }] },
      options: {
        responsive: true, maintainAspectRatio: false, animation: false, cutout: '65%', rotation: -8,
        layout: { padding: 7 },
        onHover(event, elements) {
          const hit = elements[0]?.index ?? null;
          setIndex(hit);
          event.native.target.style.cursor = hit != null && !items[hit].aggregate ? 'pointer' : 'default';
        },
        onClick(_e, elements) {
          const item = items[elements[0]?.index];
          if (item && !item.aggregate) handler.current(item.name);
        },
        plugins: { tooltip: { enabled: false } },
      },
    });
    chartRef.current = chart;
    return () => { chart.destroy(); chartRef.current = null; };
  }, [items, colors, load.basis]);
  function highlight(i) {
    const chart = chartRef.current;
    if (!chart) return;
    setIndex(i);
    const meta = i == null ? [] : [{ datasetIndex: 0, index: i }];
    chart.setActiveElements(meta); chart.update('none');
  }
  const leading = items[0];
  const focused = index == null ? null : items[index];
  const planned = load.utilization != null;
  const center = planned ? load.utilization : filter ? items.find(x => x.name === filter)?.share ?? 0 : leading?.share;
  const detail = planned ? `${measure(load.actual_hours, 'hours')} из ${measure(load.planned_hours, 'plan_hours')}`
    : 'Доля в учтённых работах, не загрузка от доступного времени';
  return <article className="chart-panel load-panel" aria-label="Нагрузка по технике">
    <div className="chart-head"><div><h2>Нагрузка по технике</h2><p>{load.basis === 'hours' ? 'Доля по моточасам' : 'Доля по записям'}</p></div><a className="icon-btn translucent" href="#results/machine" aria-label="Отчёт по машинам"><ArrowUpRight size={16}/></a></div>
    {leading ? <><div className="load-inner">
      {focused && <div className="ring-tooltip" role="tooltip"><b>{focused.name}</b><span>{load.basis === 'hours' ? `${amount(focused.value)} ч` : `${number(focused.value)} зап.`} · {number(focused.share)}%</span></div>}
      <div className="donut-frame"><canvas ref={canvas} role="img" aria-label="Распределение нагрузки по типам техники" onMouseLeave={() => setIndex(null)} /><div className="donut-center" title={detail}><strong>{number(Math.round(center))}%</strong><span>{planned ? 'от плана' : filter ? 'доля типа' : 'доля лидера'}</span></div></div>
      <ul className="load-legend" aria-label="Фильтр по типу техники">{items.map((item, n) => <li key={item.name}>
        <button type="button" disabled={!!item.aggregate} aria-pressed={filter === item.name} className={index === n ? 'highlight' : ''}
          onMouseEnter={() => highlight(n)} onMouseLeave={() => highlight(null)} onFocus={() => highlight(n)} onBlur={() => highlight(null)} onClick={() => onFilter(item.name)}
          title={`${item.name}: ${load.basis === 'hours' ? `${amount(item.value)} ч` : `${number(item.value)} зап.`} · ${number(item.share)}%`}><i style={{ '--dot': colors[n] }} /><span>{item.name}</span><b>{item.share > 0 && item.share < 1 ? '<1' : number(Math.round(item.share * 10) / 10)}%</b></button>
      </li>)}</ul>
    </div><p className="chart-note workload-note">{planned ? `${detail} · нажмите на тип для фильтра` : 'Нажмите на тип техники, чтобы отфильтровать сводку'}</p></>
      : <div className="chart-empty"><PieChart /><strong>Нет записей по технике</strong><span>Попробуйте другой период.</span></div>}
  </article>;
}

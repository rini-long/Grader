import React, { useState } from 'react';
import { AlertCircle, ArrowDownRight, ArrowUpRight, ChevronLeft, ChevronRight, ClipboardList, Download, LoaderCircle, Minus } from 'lucide-react';
import { dateText, download, measure, monthText, number, recordLink, siteLink, statuses, units } from './lib';

export function BusyIcon() { return <LoaderCircle className="animate-spin" aria-hidden="true" size={16}/>; }
export function PageHead({ eyebrow, title, description, children }) {
  return <header className="page-head"><div className="min-w-0"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{description && <p className="page-desc">{description}</p>}</div>{children && <div className="page-actions">{children}</div>}</header>;
}
export function Empty({ title, text, loading, children, icon: Glyph = ClipboardList }) {
  return <div className="empty" role={loading ? 'status' : undefined}><span>{loading ? <BusyIcon /> : <Glyph size={21}/>}</span><strong>{title}</strong>{text && <p>{text}</p>}{children}</div>;
}
export function RequestBody({ request, children }) {
  if (request.error) return <Empty icon={AlertCircle} title="Не удалось загрузить данные" text={request.error}><button type="button" className="btn secondary" onClick={request.retry}>Повторить</button></Empty>;
  if (!request.data) return <Empty loading title="Загружаем данные…" />;
  return children(request.data);
}
export function DownloadButton({ url, file = 'grader-report.xlsx', notify, iconOnly = false, caption = 'Скачать Excel', className = '', disabled = false }) {
  const [busy, setBusy] = useState(false);
  async function action() {
    if (busy) return;
    setBusy(true);
    try { await download(url, file); notify?.('Файл готов.'); }
    catch (error) { notify?.(error.message, true); }
    finally { setBusy(false); }
  }
  return <button type="button" className={`${iconOnly ? 'icon-btn' : 'btn secondary'} ${className}`} title={caption} aria-label={caption}
    aria-busy={busy} disabled={busy || disabled} onClick={action}>
    {busy ? <BusyIcon/> : <Download size={16} aria-hidden="true"/>}{!iconOnly && (busy ? 'Подготовка…' : caption)}
  </button>;
}
export function Delta({ change, metric, compact = false }) {
  if (change?.delta == null) return <span className="delta muted" title={change?.period ? `Нет сопоставимых данных за ${monthText(change.period)}` : 'Выберите месяц для сравнения с предыдущим'}><Minus size={12}/> {change?.period ? 'нет сравнения' : 'выберите месяц'}</span>;
  const { delta, percent, previous, period, current_period, whole } = change;
  const Icon = delta > 0 ? ArrowUpRight : delta < 0 ? ArrowDownRight : Minus;
  const mark = delta > 0 ? '+' : delta < 0 ? '−' : '';
  const display = percent == null && delta !== 0 ? `${mark}${measure(Math.abs(delta), metric)}` : `${mark}${number(Math.abs(percent || 0))}%`;
  return <span className={`delta ${delta > 0 ? 'up' : delta < 0 ? 'down' : 'flat'}`} title={`${monthText(current_period)} к ${monthText(period)} · было ${measure(previous, metric)}`}>
    <Icon size={13}/><b>{display}</b>{whole ? <span>{monthText(current_period, true, false)} к {monthText(period, true, false)}</span> : !compact && <span>к пред. месяцу</span>}
  </span>;
}
export function Status({ code }) { return <span className={`record-status ${code || 'verified'}`} title={statuses[code] || statuses.verified}><i/>{statuses[code] || statuses.verified}</span>; }
export function Pagination({ data, onPage }) {
  if (!data?.found) return null;
  return <footer className="pagination-bar"><span>Записи {number(data.start)}–{number(data.end)} из {number(data.found)}{data.total !== data.found ? ` · всего ${number(data.total)}` : ''}</span>
    {data.pages > 1 && <div className="flex items-center gap-2"><button aria-label="Предыдущая страница" type="button" className="icon-btn" disabled={data.page <= 1} onClick={() => onPage(data.page - 1)}><ChevronLeft size={16}/></button><span>{data.page} / {data.pages}</span><button aria-label="Следующая страница" type="button" className="icon-btn" disabled={data.page >= data.pages} onClick={() => onPage(data.page + 1)}><ChevronRight size={16}/></button></div>}</footer>;
}
export function Table({ columns, rows, rowKey, label = 'Данные', empty = 'За выбранный период нет записей' }) {
  if (!rows.length) return <Empty title={empty} text="Попробуйте изменить фильтр или загрузить журнал."/>;
  return <div className="table-scroll" tabIndex={0} role="region" aria-label={label}><table><thead><tr>{columns.map(([key, title, _render, right]) => <th key={key} scope="col" className={right ? 'numeric' : ''}>{title}</th>)}</tr></thead>
  <tbody>{rows.map((row, i) => <tr key={rowKey?.(row, i) ?? i}>{columns.map(([key, _title, render, right]) => <td key={key} className={right ? 'numeric' : ''}>{render ? render(row) : row[key] || '—'}</td>)}</tr>)}</tbody></table></div>;
}
export function journalColumns(journal, metric) {
  return [
    ['date', 'Дата', r => dateText(r.date)],
    ['site', 'Участок', r => <a className="table-link" href={siteLink(r.site)}>{r.site}</a>],
    ['machine', 'Машина', r => <div className="table-lines"><b>{r.machine}</b><small>{r.equipment_type}</small></div>],
    ['work', 'Вид работы'],
    ...(metric ? [[metric, units[metric], r => measure(r[metric], metric), true]]
      : [['distance', 'Километраж', r => measure(r.distance, 'distance'), true], ['cost', 'Затраты', r => measure(r.cost, 'cost'), true]]),
    ['row', 'Запись', r => <a className="table-link" href={recordLink(r.row, journal)}>№ {r.row} <ArrowUpRight size={12}/></a>],
  ];
}
export function StatStrip({ entries }) {
  return <div className="stat-strip surface">{entries.map(([label, text, Icon]) => <div className="stat" key={label}>{Icon && <span className="glyph"><Icon size={18}/></span>}<div><span>{label}</span><b title={String(text)}>{text}</b></div></div>)}</div>;
}

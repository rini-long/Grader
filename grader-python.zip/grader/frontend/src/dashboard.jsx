import React, { useState } from 'react';
import { ArrowRight, ArrowUpRight, CalendarDays, Check, ChevronDown, ChevronRight, Clock3, FileSpreadsheet, Fuel, HardDrive, History, ListChecks, MapPin, Route, ShieldAlert, Wallet } from 'lucide-react';
import { Delta, DownloadButton, BusyIcon, Status } from './components';
import { Trend, Workload } from './charts';
import { amount, dateText, measure, metricLabels, monthText, number, periodRange, qs, recordLink, siteLink, stamp, units, useRequest } from './lib';

export const metricIcons = { volume: Route, fuel: Fuel, hours: Clock3, cost: Wallet, distance: MapPin };
const metricKeys = ['volume', 'fuel', 'hours', 'cost'];

function Kpi({ state }) {
  return <div className="kpi-grid" aria-label="Основные показатели">{metricKeys.map(key => {
    const Glyph = metricIcons[key];
    const value = (state.clean_rows || key !== 'cost') ? state.metrics[key] : null;
    const digits = amount(value);
    const count = digits.replace(/\D/g, '').length;
    return <a key={key} href={`#metric/${key}`} className={`kpi-card ${key}`} aria-label={`${metricLabels[key]}: ${measure(value, key)}. Детализация`}>
      <span className="kpi-icon"><Glyph size={23}/></span>
      <div className="kpi-data"><h2>{metricLabels[key]}</h2><p className="kpi-figure" title={measure(value, key)} style={{ '--figure-width': Math.max(2, count * .69 + (digits.length - count) * .32) }}><strong>{digits}</strong>{value != null && <small>{units[key]}</small>}</p><Delta change={state.changes[key]} metric={key} compact /></div>
      <ArrowUpRight className="kpi-arrow" size={14}/>
    </a>;
  })}</div>;
}

export function Filters({ state, intent, change, busy, toolbar = false }) {
  if (toolbar) return <div className="type-filter">
    <label htmlFor="gear-type" className="sr-only">Тип техники</label>
    <select id="gear-type" disabled={busy || (!state.equipment_load.types.length && !intent.equipment)} value={intent.equipment} onChange={event => change({ equipment: event.target.value })}>
      <option value="">Вся техника</option>
      {intent.equipment && !state.equipment_load.types.includes(intent.equipment) && <option value={intent.equipment}>{intent.equipment}</option>}
      {state.equipment_load.types.map(type => <option value={type} key={type}>{type}</option>)}
    </select><ChevronDown size={13} aria-hidden="true"/>
  </div>;
  return <div className="master-period"><CalendarDays size={15} aria-hidden="true"/><label className="sr-only" htmlFor="period-control">Период отчёта</label>
    <select id="period-control" aria-busy={busy} value={intent.period} disabled={!state.periods.length} onChange={event => change({ period: event.target.value })}>
      <option value="">Период: весь журнал</option>
      {[...state.periods].reverse().map(month => <option key={month} value={month}>Период: {monthText(month)}</option>)}
    </select><ChevronDown size={14} aria-hidden="true"/>
  </div>;
}

export function DashboardScope({ scope, title = 'Сводка работ' }) {
  const { state, intent, setFilter, busy } = scope;
  return <div className="dashboard-top"><div><p className="eyebrow">Дорожные работы</p><h1>{title}</h1></div><div className="dashboard-filters">
    {busy && <span className="scope-progress" aria-label="Обновляем показатели"><BusyIcon/></span>}
    <span className="range-caption"><CalendarDays size={14}/>{state.period ? monthText(state.period) : periodRange(state.periods)}</span>
    <Filters state={state} intent={intent} change={setFilter} busy={busy} toolbar />
  </div></div>;
}

function Sites({ scope }) {
  const { state, params, notify } = scope;
  const [page, setPage] = useState(1);
  const request = useRequest(`/api/sites${qs({ ...params, page })}`, state.import_id || 0);
  const data = request.data;
  return <article className="summary-card sites-card"><header className="summary-head"><div><h2>Отчёт по участкам</h2><p>{data ? `Участков: ${number(data.total)} · км / м³` : 'По проверенным записям'}</p></div><MapPin className="panel-glyph" size={20}/></header>
    <div className="site-list" tabIndex={0} role="region" aria-label="Участки и объём работ">
      {request.error ? <button className="text-link" onClick={request.retry}>Повторить загрузку</button> : !data ? <span className="small-empty"><BusyIcon/> Загружаем…</span>
        : data.rows.length ? data.rows.map(site => <a key={site.name} className="site-row" href={siteLink(site.name)}>
          <span title={site.name}>{site.name}</span><span>{site.distance != null ? measure(site.distance, 'distance') : site.volume != null ? measure(site.volume, 'volume') : `${number(site.count)} зап.`}</span><ChevronRight size={13}/>
        </a>) : <p className="small-empty">Нет работ по участкам.</p>}
    </div>
    <div className="summary-foot"><DownloadButton url={`/api/report/sites${qs(params)}`} disabled={!data?.total} notify={notify} className="small teal" caption="Скачать Excel" />
      {data?.pages > 1 && <div className="mini-page"><button type="button" aria-label="Предыдущие участки" disabled={data.page === 1} onClick={() => setPage(data.page - 1)}>‹</button><span>{data.page}/{data.pages}</span><button type="button" aria-label="Следующие участки" disabled={data.page === data.pages} onClick={() => setPage(data.page + 1)}>›</button></div>}
    </div>
  </article>;
}

function Recent({ state }) {
  return <article className="summary-card recent-card"><header className="summary-head"><div><h2>Последние записи</h2><p>Из журнала работ</p></div><ListChecks className="panel-glyph" size={20}/></header>
    <div className="recent-list">{state.recent.length ? state.recent.map(row => <a href={recordLink(row.row, state.import_id)} key={row.row} className="recent-row">
      <Status code={row.status}/><time dateTime={row.date || undefined}>{dateText(row.date)}</time><div className="recent-machine"><b title={row.machine}>{row.machine}</b><span title={row.work}>{row.work}</span></div><strong>{row.distance != null ? measure(row.distance, 'distance') : row.volume != null ? measure(row.volume, 'volume') : '—'}</strong>
    </a>) : <p className="small-empty">Нет проверенных записей.</p>}</div>
    <div className="summary-foot"><a className="text-link" href="#history/records">Показать все <ArrowRight size={14}/></a></div>
  </article>;
}

function BackupTile({ scope }) {
  const { state, createCopy, copyBusy } = scope;
  const latest = state.backup.latest;
  const age = latest ? (Date.now() - new Date(latest.created_at).getTime()) / (24 * 60 * 60 * 1000) : Infinity;
  const condition = age >= 30 && latest ? 'critical' : age >= 7 ? 'stale' : 'fresh';
  const info = !latest ? 'Копий пока нет' : age >= 30 ? 'Копии больше месяца' : age >= 7 ? 'Копию стоит обновить' : 'Последняя копия';
  const Icon = latest && condition === 'fresh' ? Check : latest ? ShieldAlert : HardDrive;
  return <article className="summary-card backup-card"><header className="summary-head"><h2>Резервное копирование</h2></header>
    <a href="#backup" className={`backup-health ${condition}`} title="Открыть список резервных копий"><span className="backup-orb"><Icon size={23}/></span>
      <b>{info}</b>{latest ? <time dateTime={latest.created_at}>{stamp(latest.created_at)}</time> : <span>Снимок рабочей области</span>}
    </a>
    <button type="button" className="btn green" onClick={createCopy} disabled={copyBusy} aria-busy={copyBusy}>{copyBusy ? <BusyIcon/> : <History size={16}/>} {copyBusy ? 'Создаём…' : 'Создать копию'}</button>
  </article>;
}

export function Dashboard({ scope, chartsOnly = false }) {
  const { state, setFilter, busy } = scope;
  function pick(type) { setFilter(current => ({ equipment: current.equipment === type ? '' : type })); }
  return <section className="dashboard" aria-busy={busy}>
    <DashboardScope scope={scope} title={chartsOnly ? 'Графики' : 'Сводка работ'} />
    {!chartsOnly && <Kpi state={state} />}
    <div className="charts-grid"><Trend series={state.series} undated={state.undated_rows}/><Workload load={state.equipment_load} filter={state.equipment_type} onFilter={pick}/></div>
    {chartsOnly ? <div className="help-band surface"><span className="glyph"><CalendarDays size={19}/></span><div><h2>Как читать графики</h2><p>Кольцо сравнивает типы техники за выбранный период. В центре — процент от плана, если фактические и плановые часы есть для всех записей среза. Иначе показана доля лидера или выбранного типа.</p></div></div>
      : <><div className="summary-grid"><Sites key={`${state.period}/${state.equipment_type}/${state.import_id}`} scope={scope}/><Recent state={state}/><BackupTile scope={scope}/></div>
        <footer className="dashboard-footer"><span><FileSpreadsheet size={13}/>{state.source === 'demo' ? 'Демонстрационный набор' : state.files.raw}</span><span>{number(state.accepted_rows)} проверено{state.errors_count > 0 && <a href="#errors">Ошибки: {number(state.errors_count)}</a>}</span></footer></>}
  </section>;
}

import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { AlertCircle, ArrowDownToLine, ChartNoAxesCombined, Check, ChevronRight, Database, FileSpreadsheet, History, Info, LayoutGrid, Menu, Settings2, Table2, Upload, X } from 'lucide-react';
import { DownloadButton } from './components';
import { Dashboard, Filters } from './dashboard';
import { About, Archive, CopyPage, Import, Metric, Record, Reports, Settings, SiteDetail } from './pages';
import { api, number, qs, readRoute } from './lib';
import './styles.css';

const nav = [
  ['overview', 'Главная', LayoutGrid], ['history', 'База данных', Database], ['results', 'Отчёты', Table2],
  ['charts', 'Графики', ChartNoAxesCombined], ['backup', 'Резервное копирование', History],
  ['settings', 'Настройки', Settings2], ['about', 'О программе', Info],
];
const activeView = { import: 'history', record: 'history', errors: 'results', metric: 'results', site: 'results' };
const safeFilters = data => ({ period: data?.period || '', equipment: data?.equipment_type || '' });
function preferences() {
  try {
    const saved = JSON.parse(sessionStorage.getItem('grader-filters-v1') || '{}');
    return { period: /^\d{4}-\d{2}$/.test(saved.period || '') ? saved.period : '', equipment: typeof saved.equipment === 'string' ? saved.equipment.slice(0, 80) : '' };
  } catch { return safeFilters(); }
}

function useScope(initial, notify) {
  const [state, setState] = useState(initial), [intent, setIntent] = useState(preferences), [busy, setBusy] = useState(true);
  const [version, bump] = useState(0), [error, setError] = useState(''), [copyBusy, setCopyBusy] = useState(false);
  const pending = useRef(null), copying = useRef(false);
  function keep(next) {
    try { sessionStorage.setItem('grader-filters-v1', JSON.stringify(next)); } catch { /* private browsing */ }
    setIntent(current => current.period === next.period && current.equipment === next.equipment ? current : next);
  }
  useEffect(() => {
    const req = new AbortController(); pending.current = req; setBusy(true); setError('');
    api(`/api/state${qs(intent)}`, { signal: req.signal }).then(data => {
      if (req.signal.aborted) return;
      setState(data); keep(safeFilters(data)); setBusy(false);
    }).catch(e => { if (!req.signal.aborted) { setError(e.message); setBusy(false); } });
    return () => req.abort();
  }, [intent.period, intent.equipment, version]);
  function apply(data) {
    pending.current?.abort(); setState(data); keep(safeFilters(data)); setError(''); setBusy(false);
  }
  function setFilter(patch) {
    setIntent(prev => ({ ...prev, ...(typeof patch === 'function' ? patch(prev) : patch) }));
  }
  async function createCopy() {
    if (copying.current) return;
    copying.current = true; setCopyBusy(true);
    try {
      const { rows } = await api('/api/backups', { method: 'POST' });
      setState(s => ({ ...s, backup: { latest: rows[0] || null, count: rows.length } }));
      bump(n => n + 1);
      notify('Копия создана. Файл доступен в разделе «Резервное копирование».');
    } catch (e) { notify(e.message, true); }
    finally { copying.current = false; setCopyBusy(false); }
  }
  return { state, intent, busy, copyBusy, error, refresh: () => bump(n => n + 1), notify, apply, setFilter, createCopy,
    params: { period: state.period, equipment: state.equipment_type } };
}

function WorkspaceCard({ state }) {
  return <div className="workspace-card"><div className="workspace-cap"><span className="glyph"><FileSpreadsheet size={17}/></span><div><span className="workspace-label">Рабочая область</span><b title={state.files.raw}>{state.source === 'demo' ? 'Демо-данные' : state.files.raw}</b></div></div>
    <div className="workspace-counters"><a href="#history/records"><b>{number(state.accepted_rows)}</b><span>Проверено</span></a><a href="#errors"><b>{number(state.all_errors)}</b><span>Ошибки</span></a></div>
    <a className="workspace-upload" href="#import"><Upload size={15}/><span>Загрузить журнал</span><ChevronRight size={13}/></a>
    <a className="workspace-template" href="#about"><ArrowDownToLine size={14}/>Шаблоны Excel</a>
  </div>;
}

function App({ initial }) {
  const [route, setRoute] = useState(readRoute), [menu, openMenu] = useState(false), [toast, setToast] = useState(null);
  const timeout = useRef(), menuButton = useRef(), main = useRef(), focusRoute = useRef(false);
  function notify(text, error = false) {
    clearTimeout(timeout.current); setToast({ text, error }); timeout.current = setTimeout(() => setToast(null), error ? 6500 : 4800);
  }
  const scope = useScope(initial, notify), { state, intent, params, busy, setFilter } = scope;
  const current = activeView[route.view] || route.view;
  const routeId = `${route.view}/${route.detail}`;
  useEffect(() => {
    function changed() { focusRoute.current = true; setRoute(readRoute()); openMenu(false); window.scrollTo(0, 0); }
    window.addEventListener('hashchange', changed);
    return () => { window.removeEventListener('hashchange', changed); clearTimeout(timeout.current); };
  }, []);
  useEffect(() => {
    if (focusRoute.current) { main.current.focus({ preventScroll: true }); focusRoute.current = false; }
    const title = nav.find(([name]) => name === current)?.[1];
    document.title = route.view === 'overview' ? 'Грейдер — аналитика дорожных работ' : `${title || 'Грейдер'} — Грейдер`;
  }, [routeId, current]);
  useEffect(() => {
    if (!menu) return;
    const stop = e => { if (e.key === 'Escape') { openMenu(false); menuButton.current.focus(); } };
    const media = window.matchMedia('(min-width: 1001px)');
    const update = e => { if (e.matches) openMenu(false); };
    window.addEventListener('keydown', stop); media.addEventListener('change', update);
    document.querySelector('.sidebar a[aria-current="page"]')?.focus();
    return () => { window.removeEventListener('keydown', stop); media.removeEventListener('change', update); };
  }, [menu]);
  const scopeKey = `${routeId}/${state.import_id}/${state.period}/${state.equipment_type}`;
  let content;
  switch (route.view) {
    case 'overview': case 'charts': content = <Dashboard key={route.view} scope={scope} chartsOnly={route.view === 'charts'}/>; break;
    case 'history': content = route.detail === 'records' ? <Reports key={scopeKey} scope={scope} inHistory/> : <Archive scope={scope}/>; break;
    case 'results': content = <Reports key={scopeKey} scope={scope} kind={['site','machine','work'].includes(route.detail) ? route.detail : 'clean'}/>; break;
    case 'errors': content = <Reports key={scopeKey} scope={scope} kind="errors"/>; break;
    case 'metric': content = <Metric key={scopeKey} scope={scope} name={route.detail}/>; break;
    case 'site': content = <SiteDetail key={scopeKey} scope={scope} name={route.detail}/>; break;
    case 'record': content = <Record key={routeId} row={route.detail} journal={route.args.get('journal')}/>; break;
    case 'backup': content = <CopyPage scope={scope}/>; break;
    case 'import': content = <Import scope={scope}/>; break;
    case 'settings': content = <Settings scope={scope}/>; break;
    case 'about': content = <About database={state.database}/>; break;
  }
  return <><a href="#main" className="skip-link" onClick={e => { e.preventDefault(); main.current.focus(); }}>К содержанию</a>
    <div className="desk" data-view={route.view}>
      <header className="masthead">
        <div className="mast-brand"><button ref={menuButton} className="icon-btn menu-toggle" aria-expanded={menu} aria-controls="sidebar" aria-label="Открыть меню" onClick={() => openMenu(v => !v)}><Menu size={20}/></button>
          <a href="#overview" className="brand" aria-label="Грейдер — главная"><img src="/static/mark.svg" width="44" height="44" alt=""/><span><strong>Грейдер</strong><small>Учёт дорожных работ</small></span></a></div>
        <div className="mast-filters"><Filters state={state} intent={intent} change={setFilter} busy={busy}/></div>
        <div className="mast-actions"><a href="#import" className="btn secondary import-action" aria-label="Загрузить Excel"><Upload size={16}/><span>Загрузить Excel</span></a><DownloadButton url={`/api/report${qs(params)}`} iconOnly caption="Скачать отчёт Excel" notify={notify}/></div>
      </header>
      <div className="app-grid">
        <aside className={`sidebar ${menu ? 'is-open' : ''}`} id="sidebar"><nav aria-label="Разделы приложения">
          {nav.map(([view, label, Glyph]) => <a className={`nav-link ${view === current ? 'active' : ''}`} aria-current={view === current ? 'page' : undefined} key={view} href={`#${view}`} onClick={() => openMenu(false)}><Glyph size={18} /><span>{label}</span></a>)}
        </nav><WorkspaceCard state={state}/></aside>
        {menu && <button className="menu-shade" aria-label="Закрыть меню" tabIndex={-1} onClick={() => { openMenu(false); menuButton.current.focus(); }}/>} 
        <main className={`main-content ${route.view === 'overview' || route.view === 'charts' ? 'is-dashboard' : ''}`} id="main" ref={main} tabIndex={-1}>
          {scope.error && <div className="notice danger-note" role="alert"><AlertCircle size={17}/><span>{scope.error}</span><button type="button" className="text-link" onClick={scope.refresh}>Повторить</button></div>}
          {content}
        </main>
      </div>
    </div>
    <div className="toast-zone" aria-live="polite">{toast && <div className={`toast ${toast.error ? 'toast-error' : ''}`}>{toast.error ? <AlertCircle size={17}/> : <Check size={17}/>}<span>{toast.text}</span></div>}</div>
  </>;
}

createRoot(document.getElementById('app')).render(<App initial={JSON.parse(document.getElementById('initial-state').textContent)}/>);

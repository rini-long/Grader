import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: '../static/react', emptyOutDir: true, target: 'es2021', cssCodeSplit: false,
    rollupOptions: {
      input: fileURLToPath(new URL('./src/main.jsx', import.meta.url)),
      output: { entryFileNames: 'app.js', assetFileNames: 'app[extname]' },
    },
  },
});

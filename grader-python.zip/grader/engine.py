"""Сопоставление дорожных работ со справочником и расчёт сводок."""
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import lru_cache
from heapq import nlargest
from itertools import product
from math import isfinite, prod
import re

from openpyxl.utils.datetime import from_excel
from rapidfuzz.distance import Levenshtein

RAW_FIELDS = {"site": "Участок", "machine": "Машина", "work": "Вид работы", "cost": "Затраты"}
REF_FIELDS = {"site": "Участок", "machine": "Машина", "work": "Вид работ"}
OPTIONAL_FIELDS = {"date": "Дата", "volume": "Объём работ", "fuel": "Расход топлива", "hours": "Моточасы",
                   "distance": "Километраж, км", "plan_hours": "Плановые моточасы", "employee": "Сотрудник",
                   "status": "Статус"}
REF_OPTIONAL = {"equipment_type": "Тип техники"}
STATUS_LABELS = {"verified": "Проверено", "completed": "Завершено", "in_progress": "В процессе", "attention": "Требует проверки"}
STATUS_KEYS = {value.casefold(): key for key, value in STATUS_LABELS.items()}
FIELDS = ("site", "machine", "work")
METRICS = ("volume", "fuel", "hours")
MEASURES = (*METRICS, "distance", "plan_hours")
FIELD_NAMES = {"site": "участок", "machine": "машина", "work": "вид работы"}
DEFAULT_SETTINGS = {"threshold": .8, "hint_min": .6, "split_mode": "equal"}

ORDINALS = [("первый", "первого"), ("второй", "второго"), ("третий", "третьего"),
            ("четвертый", "четвертого"), ("пятый", "пятого"), ("шестой", "шестого"),
            ("седьмой", "седьмого"), ("восьмой", "восьмого"), ("девятый", "девятого"),
            ("десятый", "десятого")]
ALIASES = {w: "участок" for w in ("уч", "участ", "участка", "участку", "участке")}
ALIASES.update({w: str(i) for i, words in enumerate(ORDINALS, 1) for w in words})
SPLIT_RE = re.compile(r"\s*(?:\+|,|;|/|\s+и\s+)\s*", re.IGNORECASE)
NUMBER_RE = re.compile(r"[0-9]+")
PERIOD_RE = re.compile(r"[0-9]{4}-(?:0[1-9]|1[0-2])")


def text(value):
    if value is None or (isinstance(value, float) and not isfinite(value)):
        return ""
    s = str(value).strip()
    return "" if s.casefold() == "nan" else s


def normalize(value):
    s = re.sub(r"[^\w\s]", " ", text(value).casefold().replace("ё", "е").replace("№", " "))
    return " ".join(sorted(ALIASES.get(w, w) for w in s.split()))



def equipment_name(value):
    name = text(value)
    packed = name.casefold().replace("ё", "е")
    variants = (("грейдер", "Грейдеры"), ("бульдозер", "Бульдозеры"), ("погрузчик", "Погрузчики"),
                ("грузов", "Грузовики"), ("самосвал", "Самосвалы"), ("экскаватор", "Экскаваторы"),
                ("кран", "Краны"), ("трактор", "Тракторы"), ("каток", "Катки"), ("катки", "Катки"))
    return next((label for stem, label in variants if stem in packed), name[:80] if name else "Тип не указан")


def equipment_catalog(ref):
    entries = {}
    legacy = {"дз 98": "Грейдеры", "камаз 5320": "Грузовики", "кс 45717": "Краны", "мтз 80": "Тракторы"}
    legacy = {normalize(model): category for model, category in legacy.items()}
    for row in ref:
        model = text(row.get("machine"))
        if not model:
            continue
        key = normalize(model)
        if key not in entries:
            entries[key] = {"name": model, "type": None}
        explicit = text(row.get("equipment_type"))
        if explicit:
            category = equipment_name(explicit)
            if entries[key]["type"] and entries[key]["type"] != category:
                raise ValueError(f"В справочнике указаны разные типы для машины «{model}».")
            entries[key]["type"] = category
    return {item["name"]: item["type"] or legacy.get(key, "Тип не указан") for key, item in entries.items()}

def money_minor(value):
    """Денежные и количественные значения хранятся в сотых долях."""
    if isinstance(value, bool):
        return None
    s = re.sub(r"\s+", "", text(value))
    if isinstance(value, str):
        if not re.fullmatch(r"\+?[0-9]+(?:[,.][0-9]+)?", s):
            return None
        if re.fullmatch(r"[0-9]{1,3}[,.][0-9]{3}", s):
            return None  # неоднозначный разделитель: десятичный или тысячный
    try:
        n = Decimal(s.replace(",", "."))
        if not n.is_finite() or n < 0 or n > 1_000_000_000:
            return None
        return int((n * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError):
        return None


def parse_date(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (int, float)) and not isinstance(value, bool) and 1 <= value < 2958466:
        try:
            return from_excel(value).date().isoformat()
        except (AttributeError, ValueError, OverflowError):
            return None
    s = text(value)
    if PERIOD_RE.fullmatch(s) and not s.startswith("0000"):
        return s
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%d-%m-%Y", "%m.%Y", "%m/%Y"):
        try:
            d = datetime.strptime(s, fmt).date()
            return d.isoformat()[:7] if fmt in ("%m.%Y", "%m/%Y") else d.isoformat()
        except ValueError:
            pass
    return None


def validate_settings(body):
    if not isinstance(body, dict):
        raise ValueError("Передайте параметры проверки.")
    try:
        threshold = float(body["threshold"])
        hint_min = float(body["hint_min"])
        split_mode = body["split_mode"]
    except (KeyError, TypeError, ValueError):
        raise ValueError("Проверьте параметры сопоставления.") from None
    if not 0 <= hint_min <= threshold <= 1 or split_mode not in ("equal", "flag"):
        raise ValueError("Порог подсказок должен быть не выше порога автосопоставления. Допустимые значения: от 0 до 100%.")
    return {"threshold": threshold, "hint_min": hint_min, "split_mode": split_mode}


def make_lookup(ref, field):
    dictionary = {}
    for row in ref:
        name = text(row.get(field))
        norm = normalize(name)
        if norm:
            dictionary.setdefault(norm, name)
    buckets = defaultdict(list)
    for norm, name in dictionary.items():
        buckets[tuple(NUMBER_RE.findall(norm))].append((norm, name))

    @lru_cache(maxsize=8192)
    def best(key):
        if key in dictionary:
            return dictionary[key], 1.0
        best_name, score = None, 0.0
        for norm, name in buckets.get(tuple(NUMBER_RE.findall(key)), ()):
            ratio = Levenshtein.normalized_similarity(key, norm, score_cutoff=score)
            if ratio > score:
                best_name, score = name, ratio
        return best_name, score

    return dictionary, best


def split_minor(total, count):
    if total is None:
        return [None] * count
    base, remainder = divmod(total, count)
    return [base + (i < remainder) for i in range(count)]


def run(raw, ref, settings=None):
    """Вернуть очищенные строки и ошибки с исходными номерами строк Excel."""
    s = {**DEFAULT_SETTINGS, **(settings or {})}
    lookups = {f: make_lookup(ref, f) for f in FIELDS}
    sizes = {f: len(lookups[f][0]) for f in FIELDS}
    missing = [REF_FIELDS[key] for key, size in sizes.items() if not size]
    if missing:
        raise ValueError("Заполните справочник: нет значений в столбцах «" + "», «".join(missing) + "».")
    categories = equipment_catalog(ref)
    clean, errors = [], []
    for index, row in enumerate(raw, 2):
        row_no = row.get("row", index)
        days = parse_date(row.get("date"))
        month = days[:7] if days else None
        problems, hints, matched = [], [], {}
        for f in FIELDS:
            dictionary, best = lookups[f]
            value = text(row.get(f))
            if not value:
                problems.append(f"Пустое поле «{RAW_FIELDS[f]}»")
                continue
            key = normalize(value)
            if key in dictionary:
                matched[f] = [dictionary[key]]
                continue
            items = list(dict.fromkeys(p.strip() for p in SPLIT_RE.split(value) if p.strip()))
            if not items:
                problems.append(f"Пустое поле «{RAW_FIELDS[f]}»")
                continue
            found = []
            for item in items:
                name, score = best(normalize(item))
                if name and score >= s["threshold"]:
                    found.append(name)
                else:
                    problems.append(f"«{item}» не найдено ({FIELD_NAMES[f]})")
                    if name and score >= s["hint_min"]:
                        percent = int(score * 100 + .5)
                        hints.append(f"«{item}» → «{name}»? ({percent}%)")
            matched[f] = list(dict.fromkeys(found))
        cost = money_minor(row.get("cost"))
        if cost is None:
            problems.append(f"Не распознаны затраты: «{text(row.get('cost')) or 'пусто'}»")
        if text(row.get("date")) and not days:
            problems.append("Не распознана дата")
            hints.append("Укажите дату Excel или используйте формат ДД.ММ.ГГГГ")
        values = {m: money_minor(row.get(m)) for m in MEASURES}
        for metric in MEASURES:
            if text(row.get(metric)) and values[metric] is None:
                problems.append(f"Не распознано поле «{OPTIONAL_FIELDS[metric]}»")

        entered_status = text(row.get("status")).casefold()
        status = STATUS_KEYS.get(entered_status) or ("verified" if not entered_status else None)
        if status is None:
            problems.append("Не распознан статус")
            hints.append("Статус: Завершено, В процессе, Требует проверки или пусто")
        employee = text(row.get("employee")) or None

        if not problems:
            count = prod(len(matched[f]) for f in FIELDS)
            if count > 1 and s["split_mode"] == "flag":
                problems.append(f"Одна сумма на {count} сочетаний")
                hints.append("Разделите запись в Excel или измените режим в настройках")
            elif count > 1000:
                problems.append(f"Слишком много сочетаний в одной строке ({count})")
                hints.append("Разделите запись на несколько строк в Excel")
            elif len(clean) + count > 45_000:
                raise ValueError("Получается более 45 000 строк результата. Разделите журнал на несколько файлов.")

        if problems:
            errors.append({"row": row_no, "month": month, "date": days,
                           "raw": " | ".join(text(row.get(f)) or "—" for f in RAW_FIELDS),
                           "issue": "; ".join(problems), "hint": "; ".join(hints) or "—"})
            continue

        shares = {k: split_minor(v, count) for k, v in {"cost": cost, **values}.items()}
        note = f"Сумма разделена на {count} строк" if count > 1 else ""
        for idx, (site, machine, work) in enumerate(product(*(matched[f] for f in FIELDS))):
            clean.append({"row": row_no, "site": site, "machine": machine, "work": work,
                          "note": note, "date": days, "month": month,
                          "equipment_type": categories[machine], "employee": employee, "status": status,
                          **{k: amounts[idx] for k, amounts in shares.items()}})
    return {"clean": clean, "errors": errors, "dict_sizes": sizes}


def group(rows, field):
    groups = {}
    for row in rows:
        name = row[field]
        entry = groups.setdefault(name, {"name": name, "cost": 0, "count": 0})
        entry["cost"] += row["cost"]
        entry["count"] += 1
    return sorted(groups.values(), key=lambda row: (-row["cost"], row["name"].casefold()))


def periods(report):
    return sorted({r["month"] for key in ("clean", "errors") for r in report[key] if r["month"]})


def in_period(rows, period):
    return [r for r in rows if r["month"] == period] if period else rows


def machine_load(clean):
    """Доля учтённых моточасов; при отсутствии часов — доля записей по машинам."""
    entries = defaultdict(lambda: {"hours": 0, "sources": set()})
    for row in clean:
        entry = entries[row["machine"]]
        entry["hours"] += row["hours"] or 0
        entry["sources"].add(row["row"])
    has_hours = any(item["hours"] > 0 for item in entries.values())
    ranked = [{"name": name, "value": item["hours"] if has_hours else len(item["sources"])}
              for name, item in entries.items()]
    ranked = sorted((item for item in ranked if item["value"] > 0),
                    key=lambda item: (-item["value"], item["name"].casefold()))
    if len(ranked) > 3:
        ranked = ranked[:2] + [{"name": "Другие машины", "value": sum(r["value"] for r in ranked[2:])}]
    return {"basis": "hours" if has_hours else "rows", "items": ranked}


def summary(report, period=None):
    clean, errors = (in_period(report[key], period) for key in ("clean", "errors"))
    accepted = {r["row"] for r in clean}
    undated = len({r["row"] for r in clean if not r["month"]})
    totals = {"cost": 0, **{k: None for k in METRICS}}
    series = {}
    for row in clean:
        month = row["month"]
        if month:
            point = series.setdefault(month, {"month": month, "cost": 0, **{k: None for k in METRICS}})
            point["cost"] += row["cost"]
            for metric in METRICS:
                if row[metric] is not None:
                    point[metric] = (point[metric] or 0) + row[metric]
        for key in totals:
            if row[key] is not None:
                totals[key] = (totals[key] or 0) + row[key]
    site_groups, work_groups = group(clean, "site"), group(clean, "work")
    other_work = None
    if len(work_groups) > 3:
        other_work = {"name": "Другие работы", "cost": sum(r["cost"] for r in work_groups[3:]),
                      "count": sum(r["count"] for r in work_groups[3:])}
    recent = nlargest(3, clean, key=lambda r: (r["date"] or "", r["row"]))
    return {
        "load": machine_load(clean),
        "recent": [{k: row[k] for k in ("date", "row", "machine", "work", "volume")} for row in recent],
        "period": period or "", "periods": periods(report), "metrics": totals,
        "total_rows": len(accepted) + len(errors), "accepted_rows": len(accepted),
        "clean_rows": len(clean), "errors_count": len(errors), "all_errors": len(report["errors"]),
        "undated_rows": undated, "machine_count": len({r["machine"] for r in clean}),
        "work_count": len(work_groups), "site_count": len(site_groups), "by_site": site_groups[:3],
        "by_work": work_groups[:3] + ([other_work] if other_work else []),
        "series": sorted(series.values(), key=lambda r: r["month"]), "dict_sizes": report["dict_sizes"],
    }


def make_demo():
    ref = [
        {"site": "Участок №1", "machine": "КамАЗ-5320", "work": "Планировка", "equipment_type": "Грузовики"},
        {"site": "Участок №2", "machine": "МТЗ-80", "work": "Перевозка грунта", "equipment_type": "Тракторы"},
        {"site": "Участок №3", "machine": "ДЗ-98", "work": "Укладка асфальта", "equipment_type": "Грейдеры"},
        {"site": "Участок №5", "machine": "КС-45717", "work": "", "equipment_type": "Краны"},
    ]
    lines = [
        ("2026-01-09", "уч. 1", "КАМАЗ 5320", "планировка", 124000, 110, 495, 26),
        ("2026-01-17", "Участок №2", "МТЗ-80", "Перевозка грунта", 96000, 70, 378, 18),
        ("2026-01-22", "Участок №3", "ДЗ-98", "Планировка", 65000, 40, 307, 18),
        ("2026-02-04", "участок 1", "ДЗ-98", "Планировка", 184000, 205, 1020, 48),
        ("2026-02-12", "Участок №3", "КамАЗ-5320", "Перевозка грунта", 145000, 140, 785, 37),
        ("2026-02-24", "Пятый участок", "КамАЗ-5320 + МТЗ-80", "Укладка асфальта", 107000, 135, 645, 29),
        ("2026-03-03", "Участок №2", "КС-45717", "Укладка асфальта", 397000, 260, 1300, 61),
        ("2026-03-14", "Уч.3 + Участок 1", "ДЗ-98", "Перевозка грунта", 332000, 180, 1090, 56),
        ("2026-03-19", "Участок №5", "МТЗ-80", "Планировка", 214000, 120, 730, 41),
        ("2026-03-27", "Участок №1", "КамАЗ-5320", "Перевозка гравия", 34000, 24, 160, 7),
        ("2026-04-06", "Участок №1", "ДЗ-98", "Планировка", 382000, 410, 1710, 85),
        ("2026-04-14", "Участок №2", "КамАЗ-5320", "Перевозка грунта", 266000, 300, 1370, 72),
        ("2026-04-22", "Участок №3", "КС-45717", "Укладка асфальта", 174000, 220, 1010, 55),
        ("2026-04-27", "Участок 99", "ГАЗ-3309", "Планировка", 19000, 30, 127, 6),
    ]
    keys = ("date", "site", "machine", "work", "cost", "volume", "fuel", "hours")
    distances = (2.3, 1.6, 1.9, 4.2, 2.8, 3.1, 5.2, 3.6, 2.9, .4, 7.2, 5.8, 4.6, .9)
    plans = (34, 24, 24, 54, 46, 42, 80, 70, 53, 12, 102, 94, 77, 10)
    people = ("Алексей Смирнов", "Мария Орлова", "Илья Волков", "Анна Соколова")
    statuses = {11: "В процессе", 13: "Требует проверки"}
    return [dict(zip(keys, line), row=i+2, distance=distances[i], plan_hours=plans[i],
                 employee=people[i % len(people)], status=statuses.get(i, "Завершено"))
            for i, line in enumerate(lines)], ref

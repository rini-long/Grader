"""Грейдер — веб-приложение Flask для проверки и аналитики дорожных работ."""
from datetime import UTC, datetime
from io import BytesIO
import os
from pathlib import Path
import re

from flask import Flask, jsonify, render_template, request, send_file
from werkzeug.exceptions import RequestEntityTooLarge

from analytics import KPI_KEYS, comparisons, recent_entries, scope_report, site_totals, totals, workload
from engine import (DEFAULT_SETTINGS, group, in_period, make_demo, normalize, periods, run, summary,
                    validate_settings)
from spreadsheets import (MAX_BYTES, MIME_XLSX, read_upload, workbook_for_input, workbook_for_metric,
                          workbook_for_report, workbook_for_sites)
from storage import ActiveImportChanged, BACKUP_LIMIT, open_storage


def make_workspace(source="demo", raw=None, ref=None, settings=None, files=None):
    settings = dict(settings or DEFAULT_SETTINGS)
    if source == "demo":
        raw, ref = make_demo()
        files = {"raw": "demo-works.xlsx", "ref": "demo-reference.xlsx"}
    return {"source": source, "import_id": None, "raw": raw, "ref": ref, "settings": settings, "files": files,
            "updated_at": datetime.now(UTC).isoformat() if source == "import" else None,
            "report": run(raw, ref, settings)}


def compact_legacy(data):
    settings = data["settings"]
    demo = data["source"] == "Демо-данные"
    return {
        "source": "demo" if demo else "import", "raw": data["raw"], "ref": data["ref"],
        "settings": {"threshold": settings["threshold"] / 100, "hint_min": settings["hint"] / 100,
                     "split_mode": settings["split"]},
        "files": data.get("files") or {"raw": "Журнал работ", "ref": "Справочник"},
        "report": {"clean": data["clean"], "errors": data["errors"],
                   "dict_sizes": {k: len({normalize(row.get(k)) for row in data["ref"]} - {""})
                                  for k in ("site", "machine", "work")}},
    }


def create_app(config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        DATABASE=os.environ.get("GRADER_DATABASE", str(Path(app.instance_path) / "grader.sqlite3")),
        DATABASE_URL=os.environ.get("DATABASE_URL"),
        MAX_CONTENT_LENGTH=2 * MAX_BYTES + 1024 * 1024,
        MAX_FORM_MEMORY_SIZE=128 * 1024,
        MAX_FORM_PARTS=8,
        STANDALONE=False,
    )
    if config:
        app.config.update(config)
    store = open_storage(app.config["DATABASE"], app.config["DATABASE_URL"])
    if app.config["STANDALONE"] and store.backend == "SQLite":
        store._migrate("workspaces", "data", compact_legacy)
    demo = make_workspace()
    def dashboard(workspace, period=None, equipment_type=None):
        full = workspace["report"]
        scoped = scope_report(full, period, equipment_type)
        choice_rows = in_period(full["clean"], period)
        # Секторы показывают структуру периода даже при включённом фильтре типа.
        load = workload(choice_rows, scoped["clean"])
        return {
            **summary(scoped), "period": period or "", "periods": periods(full), "equipment_type": equipment_type or "",
            "all_errors": len(full["errors"]), "equipment_load": load,
            "changes": comparisons(full, scoped["clean"], period, equipment_type),
            "recent": recent_entries(scoped["clean"]),
            "distance": totals(scoped["clean"])["distance"],
            **{k: workspace[k] for k in ("source", "files", "settings", "updated_at", "import_id")},
            "database": store.backend,
        }

    demo_initial = dashboard(demo)
    demo_initial.update(storage={"imports_count": 0, "rows_count": 0}, backup={"count": 0, "latest": None})

    def workspace_id():
        key = request.headers.get("X-Workspace", "")
        if not re.fullmatch(r"[a-zA-Z0-9_-]{24,80}", key):
            return None
        if app.config["STANDALONE"]:
            old = request.cookies.get("grader_workspace", "")
            if re.fullmatch(r"[a-f0-9]{48}", old):
                return old
        return key

    def require_workspace():
        key = workspace_id()
        if not key:
            raise ValueError("Не удалось определить рабочую область. Обновите страницу и попробуйте снова.")
        return key

    def current_workspace(include_inputs=False):
        key = workspace_id()
        if not key:
            return demo
        item = store.current(key, include_inputs)
        if item["source"] == "import":
            return item
        settings = item["settings"] or DEFAULT_SETTINGS
        return demo if settings == DEFAULT_SETTINGS else make_workspace(settings=settings)

    def selected_period(report):
        key = request.args.get("period", "")
        return key if key and key in periods(report) else None

    def selected_type(report):
        category = request.args.get("equipment", "")[:80]
        return category if category and any(row["equipment_type"] == category for row in report["clean"]) else None

    def scope_args(report):
        return selected_period(report), selected_type(report)

    def snapshot(workspace, period=None, equipment_type=None):
        key = workspace_id()
        base = demo_initial if workspace is demo and not period and not equipment_type else dashboard(workspace, period, equipment_type)
        if not key and base is demo_initial:
            return demo_initial
        backups = store.list_backups(key) if key else []
        return {**base, "storage": store.stats(key) if key else demo_initial["storage"],
                "backup": {"count": len(backups), "latest": backups[0] if backups else None}}

    def paginated(rows, size=10, total=None):
        found = len(rows)
        pages = max(1, (found + size - 1) // size)
        page = max(1, min(pages, request.args.get("page", 1, type=int)))
        start = (page - 1) * size
        return dict(rows=rows[start:start + size], total=found if total is None else total, found=found,
                    page=page, pages=pages, start=(start + 1 if found else 0), end=min(start+size, found))

    def by_newest(rows):
        return sorted(rows, key=lambda row: (row.get("date") or "", row["row"]), reverse=True)

    @app.after_request
    def no_private_cache(response):
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        return response

    @app.errorhandler(ValueError)
    def bad_data(error):
        return jsonify(error=str(error)), 400

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_error):
        return jsonify(error="Файлы слишком большие. Максимальный размер одного файла — 10 МБ."), 413

    @app.get("/")
    def index():
        return render_template("index.html", initial=demo_initial)

    @app.get("/api/state")
    def state():
        workspace = current_workspace()
        return jsonify(snapshot(workspace, *scope_args(workspace["report"])))

    @app.post("/api/import")
    def upload():
        key = require_workspace()
        files = {}
        sheets = {}
        for kind, label in (("raw", "Журнал работ"), ("ref", "Справочник")):
            item = request.files.get(kind)
            try:
                sheets[kind] = read_upload(item, kind)
            except ValueError as error:
                raise ValueError(f"{label}: {error}") from None
            files[kind] = item.filename.replace("\\", "/").split("/")[-1][:180]
        workspace = make_workspace("import", sheets["raw"], sheets["ref"], store.get_settings(key), files)
        workspace["import_id"] = store.add_import(key, workspace)
        return jsonify(snapshot(workspace))

    @app.post("/api/demo")
    def reset_demo():
        key = require_workspace()
        settings = store.get_settings(key) or DEFAULT_SETTINGS
        store.show_demo(key, settings)
        return jsonify(snapshot(demo if settings == DEFAULT_SETTINGS else make_workspace(settings=settings)))

    @app.post("/api/settings")
    def set_settings():
        key = require_workspace()
        settings = validate_settings(request.get_json(silent=True))
        old = current_workspace(include_inputs=True)
        workspace = make_workspace(old["source"], old["raw"], old["ref"], settings, old["files"])
        workspace["updated_at"] = old["updated_at"]
        workspace["import_id"] = old["import_id"]
        try:
            store.update_settings(key, settings, workspace["import_id"], workspace["report"])
        except ActiveImportChanged:
            return jsonify(error="Активный журнал изменился. Обновите страницу и повторите проверку."), 409
        return jsonify(snapshot(workspace, *scope_args(workspace["report"])))

    @app.get("/api/imports")
    def imports():
        return jsonify(store.list_imports(workspace_id(), request.args.get("page", 1, type=int)))

    def missing_import():
        return jsonify(error="Загрузка не найдена в этой рабочей области."), 404

    @app.post("/api/imports/<int:import_id>/open")
    def open_import(import_id):
        key = require_workspace()
        if not 1 <= import_id < 2**63 or not store.activate(key, import_id):
            return missing_import()
        return jsonify(snapshot(current_workspace()))

    @app.delete("/api/imports/<int:import_id>")
    def delete_import(import_id):
        key = require_workspace()
        if not 1 <= import_id < 2**63 or not store.discard(key, import_id):
            return missing_import()
        workspace = current_workspace()
        return jsonify(snapshot(workspace, *scope_args(workspace["report"])))

    @app.get("/api/imports/<int:import_id>/report")
    def export_import(import_id):
        key = workspace_id()
        if not key or not 1 <= import_id < 2**63:
            return missing_import()
        workspace = store.get_import(key, import_id)
        if not workspace:
            return missing_import()
        return send_file(workbook_for_report(workspace["report"]), mimetype=MIME_XLSX,
                         as_attachment=True, download_name=f"grader-report-{import_id}.xlsx")

    @app.get("/api/table")
    def table():
        workspace = current_workspace()
        report = workspace["report"]
        period = selected_period(report)
        kind = request.args.get("kind", "clean")
        scoped = scope_report(report, period, selected_type(report))
        if kind == "errors":
            rows = in_period(report["errors"], period)
        elif kind == "clean":
            rows = by_newest(scoped["clean"])
        elif kind == "site":
            rows = site_totals(scoped["clean"])
        elif kind in ("machine", "work"):
            rows = group(scoped["clean"], kind)
        else:
            raise ValueError("Неизвестный вид таблицы.")
        query = request.args.get("q", "").strip().casefold().replace("ё", "е")[:160]
        total = len(rows)
        if query:
            words = query.split()

            def contains(row):
                blob = " ".join(str(v) for k, v in row.items() if k != "month" and v is not None)
                date = row.get("date") or ""
                if len(date) == 10:
                    blob += " " + ".".join(reversed(date.split("-")))
                folded = blob.casefold().replace("ё", "е")
                return all(word in folded for word in words)

            rows = [row for row in rows if contains(row)]
        return jsonify(paginated(rows, total=total))

    @app.get("/api/sites")
    def sites_list():
        report = current_workspace()["report"]
        rows = site_totals(scope_report(report, *scope_args(report))["clean"])
        return jsonify(paginated(rows, size=20))

    @app.get("/api/site")
    def site_detail():
        workspace = current_workspace()
        report = workspace["report"]
        name = request.args.get("name", "")[:500]
        match = [row for row in report["clean"] if row["site"] == name]
        if not name or not match:
            return jsonify(error="Участок не найден в текущем журнале."), 404
        rows = scope_report({**report, "clean": match}, *scope_args(report))["clean"]
        return jsonify(name=name, totals=totals(rows), journal=workspace["import_id"], **paginated(by_newest(rows)))

    @app.get("/api/metric/<metric>")
    def metric_detail(metric):
        if metric not in KPI_KEYS:
            return jsonify(error="Такого показателя нет."), 404
        workspace = current_workspace()
        report = workspace["report"]
        period, category = scope_args(report)
        scoped = scope_report(report, period, category)
        rows = [row for row in scoped["clean"] if row.get(metric) is not None]
        return jsonify(key=metric, value=totals(rows)[metric], change=comparisons(report, rows, period, category)[metric],
                       by_site=sorted([el for el in site_totals(rows) if el[metric] is not None], key=lambda el: -el[metric])[:6],
                       series=summary(scoped)["series"], journal=workspace["import_id"], **paginated(by_newest(rows)))

    @app.get("/api/records/<int:row_num>")
    def record_detail(row_num):
        journal = request.args.get("journal")
        key = workspace_id()
        if journal == "demo":
            workspace = demo
        elif journal is not None:
            if not re.fullmatch(r"[1-9][0-9]{0,18}", journal) or int(journal) >= 2**63:
                return missing_import()
            workspace = store.get_import(key, int(journal), include_inputs=True) if key else None
            if not workspace:
                return missing_import()
        else:
            workspace = current_workspace(include_inputs=True)
        raw = next((r for r in workspace["raw"] if r.get("row") == row_num), None)
        if raw is None:
            return jsonify(error="Запись не найдена в журнале."), 404
        report = workspace["report"]
        checked = [row for row in report["clean"] if row["row"] == row_num]
        error = next((row for row in report["errors"] if row["row"] == row_num), None)
        return jsonify(raw=raw, checked=checked, error=error, totals=totals(checked), files=workspace["files"],
                       journal=workspace["import_id"])

    @app.get("/api/report")
    def export():
        report = current_workspace()["report"]
        period, category = scope_args(report)
        return send_file(workbook_for_report(scope_report(report, period, category)), mimetype=MIME_XLSX, as_attachment=True,
                         download_name=f"grader-report{('-' + period) if period else ''}.xlsx")

    @app.get("/api/report/sites")
    def export_sites():
        report = current_workspace()["report"]
        period, category = scope_args(report)
        scoped = scope_report(report, period, category)
        name = request.args.get("site", "")[:500]
        if name:
            scoped["clean"] = [row for row in scoped["clean"] if row["site"] == name]
        return send_file(workbook_for_sites(scoped), mimetype=MIME_XLSX, as_attachment=True,
                         download_name=f"grader-sites{('-' + period) if period else ''}.xlsx")

    @app.get("/api/report/metric/<metric>")
    def export_metric(metric):
        if metric not in KPI_KEYS:
            return jsonify(error="Такого показателя нет."), 404
        report = current_workspace()["report"]
        period, category = scope_args(report)
        scoped = scope_report(report, period, category)
        return send_file(workbook_for_metric(scoped["clean"], metric), mimetype=MIME_XLSX, as_attachment=True,
                         download_name=f"grader-{metric}{('-' + period) if period else ''}.xlsx")

    @app.get("/api/backups")
    def backups():
        key = workspace_id()
        return jsonify(rows=store.list_backups(key) if key else [], limit=BACKUP_LIMIT)

    @app.post("/api/backups")
    def create_backup():
        rows = store.create_backup(require_workspace(), DEFAULT_SETTINGS)
        return jsonify(rows=rows, limit=BACKUP_LIMIT), 201

    @app.get("/api/backups/<int:backup_id>/file")
    def download_backup(backup_id):
        key = workspace_id()
        item = store.get_backup(key, backup_id) if key and 1 <= backup_id < 2**63 else None
        if not item:
            return jsonify(error="Копия не найдена в этой рабочей области."), 404
        return send_file(BytesIO(item["payload"]), mimetype="application/vnd.sqlite3", as_attachment=True,
                         download_name=f"grader-backup-{backup_id}.sqlite3")

    @app.get("/files/<name>.xlsx")
    def input_file(name):
        allowed = {"template-works": ("raw", False), "template-reference": ("ref", False),
                   "demo-works": ("raw", True), "demo-reference": ("ref", True)}
        if name not in allowed:
            return jsonify(error="Такого шаблона нет."), 404
        return send_file(workbook_for_input(*allowed[name]), mimetype=MIME_XLSX, as_attachment=True,
                         download_name=f"{name}.xlsx")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))

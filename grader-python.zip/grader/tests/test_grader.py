import sys
from io import BytesIO
from pathlib import Path

import pytest
from openpyxl import Workbook, load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import create_app
from engine import make_demo, money_minor, normalize, run, summary

TOKEN = {"X-Workspace": "grader-test-workspace-437c99af1000"}


def workbook(*rows):
    wb = Workbook()
    for row in rows:
        wb.active.append(row)
    data = BytesIO()
    wb.save(data)
    data.seek(0)
    return data


@pytest.fixture
def client(tmp_path):
    return create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.sqlite3")}).test_client()


def test_names_and_amounts():
    assert normalize("пятый УЧ.") == normalize("Участок №5")
    assert normalize("КАМАЗ-5320") == normalize("КамАЗ 5320")
    assert money_minor("12 000,25") == 1_200_025
    assert money_minor("12.000") is None
    assert money_minor("45руб") is None
    assert money_minor(-1) is None


def test_normalization_hints_and_groups():
    raw, ref = make_demo()
    report = run(raw, ref)
    totals = summary(report)
    assert totals["total_rows"] == 14
    assert totals["accepted_rows"] == 12
    assert totals["clean_rows"] == 14
    assert totals["metrics"] == {"cost": 248600000, "hours": 54600, "volume": 219000, "fuel": 1084000}
    assert "Перевозка грунта" in report["errors"][0]["hint"]
    assert report["errors"][1]["row"] == 15
    assert summary(report, "2026-04")["metrics"]["cost"] == 82200000


def test_exact_names_with_separators_and_division_in_cents():
    ref = [{"site": "Участок №1", "machine": "МТЗ-80", "work": "Погрузка и разгрузка"},
           {"site": "Участок №2", "machine": "ДЗ-98"}]
    row = {"site": "уч. 1 / второй участок", "machine": "МТЗ-80", "work": "Погрузка и разгрузка",
           "cost": "100,01", "volume": "1,01"}
    report = run([row], ref)
    assert [r["cost"] for r in report["clean"]] == [5001, 5000]
    assert [r["volume"] for r in report["clean"]] == [51, 50]
    assert len(run([row], ref, {"split_mode": "flag"})["errors"]) == 1
    assert not run([{**row, "machine": "МТЗ-81"}], ref)["clean"]


def test_import_templates_report_and_settings(client):
    demo_rows = client.get('/files/demo-works.xlsx').data
    demo_ref = client.get('/files/demo-reference.xlsx').data
    result = client.post('/api/import', headers=TOKEN, data={
        'raw': (BytesIO(demo_rows), 'мой журнал.xlsx'), 'ref': (BytesIO(demo_ref), 'справочник.xlsx')})
    assert result.status_code == 200 and result.json['source'] == 'import'
    assert client.get('/api/state', headers=TOKEN).json['files']['raw'] == 'мой журнал.xlsx'
    assert client.get('/api/state').json['source'] == 'demo'
    march = client.get('/api/report?period=2026-03', headers=TOKEN)
    assert march.status_code == 200
    wb = load_workbook(BytesIO(march.data), read_only=True, data_only=True)
    assert wb.sheetnames == ['Чистый результат', 'По участкам', 'По машинам', 'По видам работ', 'Ошибки']
    assert sum(r[3] for r in list(wb.worksheets[0].values)[1:]) == 943000
    assert wb['Ошибки'].max_row == 2
    wb.close()
    result = client.post('/api/settings', headers=TOKEN, json={'threshold': .8, 'hint_min': .6, 'split_mode': 'flag'})
    assert result.status_code == 200 and result.json['all_errors'] == 4
    result = client.post('/api/settings', headers=TOKEN, json={'threshold': .4, 'hint_min': .6, 'split_mode': 'equal'})
    assert result.status_code == 400
    result = client.post('/api/demo', headers=TOKEN)
    assert result.status_code == 200 and result.json['source'] == 'demo'


def test_xlsx_validation_and_original_line_number(client):
    raw = workbook(['Участок', 'Машина', 'Вид работы', 'Затраты'],
                   ['уч. 1', 'КАМАЗ 5320', 'планировка', '15 000,45'],
                   [None, None, None, None], ['уч. 42', 'КамАЗ-5320', 'планировка', 19])
    ref = workbook(['Участок', 'Машина', 'Вид работ'], ['Участок №1', 'КамАЗ-5320', 'Планировка'])
    result = client.post('/api/import', headers=TOKEN, data={'raw': (raw, 'works.XLSX'), 'ref': (ref, 'ref.xlsx')})
    assert result.status_code == 200
    assert result.json['metrics']['cost'] == 1500045
    assert result.json['series'] == []
    rows = client.get('/api/table?kind=errors', headers=TOKEN).json['rows']
    assert rows[0]['row'] == 4
    invalid = workbook(['Участок', 'Машина', 'Затраты'], ['уч. 1', 'КАМАЗ', 300])
    result = client.post('/api/import', headers=TOKEN, data={'raw': (invalid, 'invalid.xlsx'), 'ref': (BytesIO(), 'ref.xlsx')})
    assert result.status_code == 400 and 'Вид работы' in result.json['error']
    assert client.get('/api/state', headers=TOKEN).json['metrics']['cost'] == 1500045


def test_search_and_pagination(client):
    page = client.get('/api/table?kind=clean&page=2').json
    assert page['found'] == 14 and page['page'] == 2 and len(page['rows']) == 4
    search = client.get('/api/table', query_string={'kind': 'clean', 'q': 'асфальта'}).json
    assert search['found'] == 4
    filtered = client.get('/api/table?kind=errors&period=2026-01').json
    assert filtered['found'] == 0


def test_history_restore_delete_and_persistence(tmp_path):
    import sqlite3

    config = {'TESTING': True, 'DATABASE': str(tmp_path / 'history.sqlite3')}
    c = create_app(config).test_client()
    other = {'X-Workspace': 'a-different-grader-workspace-key'}
    assert c.get('/api/imports', headers=TOKEN).json['rows'] == []
    assert c.get('/api/state', headers=TOKEN).json['storage'] == {'imports_count': 0, 'rows_count': 0}
    ref = c.get('/files/demo-reference.xlsx').data

    def upload(filename, cost):
        raw = workbook(['Участок', 'Машина', 'Вид работы', 'Затраты', 'Дата'],
                       ['уч. 1', 'КамАЗ-5320', 'Планировка', cost, '2026-05'])
        result = c.post('/api/import', headers=TOKEN, data={
            'raw': (raw, filename), 'ref': (BytesIO(ref), 'Справочник.xlsx')})
        assert result.status_code == 200
        return result.json['import_id']

    first = upload('первый.xlsx', 1000)
    second = upload('второй.xlsx', 3000)
    assert first != second
    assert c.get('/api/state', headers=TOKEN).json['storage'] == {'imports_count': 2, 'rows_count': 2}
    result = c.get('/api/imports', headers=TOKEN).json
    assert [(row['id'], row['active']) for row in result['rows']] == [(second, 1), (first, 0)]
    assert c.get('/api/imports', headers=other).json['total'] == 0
    assert c.post(f'/api/imports/{first}/open', headers=other).status_code == 404
    assert c.get(f'/api/imports/{first}/report', headers=other).status_code == 404
    assert c.delete(f'/api/imports/{first}', headers=other).status_code == 404

    report = c.get(f'/api/imports/{first}/report', headers=TOKEN)
    book = load_workbook(BytesIO(report.data), read_only=True, data_only=True)
    assert list(book.worksheets[0].values)[1][3] == 1000
    book.close()
    assert c.get('/api/state', headers=TOKEN).json['import_id'] == second

    # Перезапуск Flask использует ту же базу, а не данные процесса.
    c = create_app(config).test_client()
    assert c.get('/api/state', headers=TOKEN).json['import_id'] == second
    assert c.post(f'/api/imports/{first}/open', headers=TOKEN).json['metrics']['cost'] == 100000
    updated = c.post('/api/settings', headers=TOKEN,
                     json={'threshold': .91, 'hint_min': .6, 'split_mode': 'equal'}).json
    assert updated['import_id'] == first and updated['storage']['imports_count'] == 2
    demo = c.post('/api/demo', headers=TOKEN).json
    assert demo['source'] == 'demo' and demo['storage']['imports_count'] == 2
    assert c.post(f'/api/imports/{second}/open', headers=TOKEN).json['settings']['threshold'] == .8
    assert c.post(f'/api/imports/{first}/open', headers=TOKEN).json['settings']['threshold'] == .91
    after = c.delete(f'/api/imports/{first}', headers=TOKEN).json
    assert after['source'] == 'demo' and after['storage']['imports_count'] == 1
    assert c.get(f'/api/imports/{first}/report', headers=TOKEN).status_code == 404

    with sqlite3.connect(config['DATABASE']) as db:
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        for table in ('raw_rows', 'reference_rows', 'clean_rows', 'error_rows'):
            assert db.execute(f'SELECT COUNT(*) FROM {table} WHERE import_id=?', (first,)).fetchone()[0] == 0
        assert db.execute('SELECT cost FROM clean_rows WHERE import_id=?', (second,)).fetchone() == (300000,)


def test_legacy_import_is_migrated_only_once(tmp_path):
    import json
    import sqlite3
    from app import make_workspace

    path = tmp_path / 'legacy.sqlite3'
    raw, ref = make_demo()
    old = make_workspace('import', raw, ref, files={'raw': 'old.xlsx', 'ref': 'ref.xlsx'})
    old.pop('import_id')
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE workspace (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
        db.execute('INSERT INTO workspace VALUES (?, ?)', (TOKEN['X-Workspace'], json.dumps(old)))
    config = {'TESTING': True, 'DATABASE': str(path)}
    c = create_app(config).test_client()
    current = c.get('/api/state', headers=TOKEN).json
    assert current['files']['raw'] == 'old.xlsx'
    assert current['metrics']['cost'] == 248600000
    assert current['storage'] == {'imports_count': 1, 'rows_count': 14}
    ident = current['import_id']
    c = create_app(config).test_client()
    assert c.get('/api/imports', headers=TOKEN).json['total'] == 1
    assert c.delete(f'/api/imports/{ident}', headers=TOKEN).status_code == 200
    c = create_app(config).test_client()
    assert c.get('/api/imports', headers=TOKEN).json['total'] == 0


def test_chart_load_and_recent_follow_period(client):
    state = client.get('/api/state').json
    assert state['load']['basis'] == 'hours'
    assert sum(item['value'] for item in state['load']['items']) == state['metrics']['hours'] == 54600
    assert state['load']['items'][0] == {'name': 'ДЗ-98', 'value': 20700}
    assert state['load']['items'][-1]['name'] == 'Другие машины'
    assert [row['date'] for row in state['recent']] == ['2026-04-22', '2026-04-14', '2026-04-06']
    march = client.get('/api/state?period=2026-03').json
    assert len(march['recent']) == 3 and all(row['date'].startswith('2026-03') for row in march['recent'])
    assert sum(item['value'] for item in march['load']['items']) == march['metrics']['hours']
    assert all(row['date'] != '2026-03-27' for row in march['recent'])


def test_machine_load_without_hours():
    from engine import machine_load

    # Одна строка может делиться по участкам; в доле по записям не считаем её дважды для одной машины.
    data = [{'row': 2, 'machine': 'КамАЗ-5320', 'hours': None}] * 2
    data += [{'row': 3, 'machine': 'КамАЗ-5320', 'hours': 0}, {'row': 4, 'machine': 'ДЗ-98', 'hours': None}]
    assert machine_load(data) == {'basis': 'rows', 'items': [
        {'name': 'КамАЗ-5320', 'value': 2}, {'name': 'ДЗ-98', 'value': 1},
    ]}
    assert machine_load([])['items'] == []


def test_site_report_follows_period(client):
    result = client.get('/api/report/sites?period=2026-03', headers=TOKEN)
    assert result.status_code == 200 and 'grader-sites-2026-03.xlsx' in result.headers['Content-Disposition']
    wb = load_workbook(BytesIO(result.data), read_only=True, data_only=True)
    assert wb.sheetnames == ['Отчёт по участкам', 'История работ']
    values = list(wb.active.values)
    assert values[0][:3] == ('Участок', 'Затраты', 'Записей')
    assert sum(row[1] for row in values[1:]) == 943000
    assert sum(row[2] for row in values[1:]) == 4
    wb.close()


def test_backup_isolated_persistent_and_restorable(tmp_path):
    import sqlite3
    from storage import BACKUP_LIMIT

    other = {'X-Workspace': 'very-different-grader-workspace'}
    config = {'TESTING': True, 'DATABASE': str(tmp_path / 'live.sqlite3')}
    c = create_app(config).test_client()
    assert c.get('/api/backups', headers=TOKEN).json['rows'] == []
    assert c.post('/api/backups').status_code == 400
    assert c.get('/api/state', headers=TOKEN).json['backup'] == {'count': 0, 'latest': None}
    work = c.get('/files/demo-works.xlsx').data
    ref = c.get('/files/demo-reference.xlsx').data

    def upload(token, filename):
        return c.post('/api/import', headers=token, data={
            'raw': (BytesIO(work), filename), 'ref': (BytesIO(ref), 'reference.xlsx'),
        }).json['import_id']

    first = upload(TOKEN, 'archive.xlsx')
    upload(other, 'not-in-my-backup.xlsx')
    second = upload(TOKEN, 'active.xlsx')
    settings = {'threshold': .87, 'hint_min': .6, 'split_mode': 'equal'}
    assert c.post('/api/settings', headers=TOKEN, json=settings).status_code == 200
    created = c.post('/api/backups', headers=TOKEN)
    assert created.status_code == 201
    entry = created.json['rows'][0]
    assert entry['import_count'] == 2 and entry['size_bytes'] >= 4096
    assert c.get('/api/state', headers=TOKEN).json['backup'] == {'count': 1, 'latest': entry}
    assert c.get('/api/backups', headers=other).json['rows'] == []
    assert c.get('/api/backups').json['rows'] == []
    url = f"/api/backups/{entry['id']}/file"
    assert c.get(url, headers=other).status_code == 404
    assert c.get(url).status_code == 404
    assert c.get('/api/backups/999999999999999999999/file', headers=TOKEN).status_code == 404
    # Снимок остаётся неизменным после удаления исходной загрузки и перезапуска.
    assert c.delete(f'/api/imports/{second}', headers=TOKEN).status_code == 200
    c = create_app(config).test_client()
    saved = c.get(url, headers=TOKEN)
    assert saved.status_code == 200 and saved.headers['Cache-Control'] == 'no-store'
    assert len(saved.data) == entry['size_bytes'] and saved.data[:16] == b'SQLite format 3\x00'
    exported = tmp_path / 'snapshot.sqlite3'
    exported.write_bytes(saved.data)
    with sqlite3.connect(exported) as db:
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        assert db.execute('SELECT id, raw_file FROM imports ORDER BY id').fetchall() == [(first, 'archive.xlsx'), (second, 'active.xlsx')]
        assert db.execute('SELECT COUNT(*) FROM workspace_settings').fetchone() == (1,)
        assert db.execute('SELECT COUNT(*) FROM workspace_backups').fetchone() == (0,)
        assert db.execute('SELECT COUNT(*) FROM raw_rows').fetchone() == (28,)
        assert db.execute('SELECT COUNT(*) FROM error_rows').fetchone() == (4,)
    clone = create_app({**config, 'DATABASE': str(exported)}).test_client()
    assert clone.get('/api/state', headers=TOKEN).json['import_id'] == second
    assert clone.get('/api/state', headers=TOKEN).json['settings'] == settings
    assert clone.get('/api/report', headers=TOKEN).status_code == 200
    # Ротация действует только на копии этой рабочей области.
    assert c.post('/api/backups', headers=other).status_code == 201
    for _ in range(BACKUP_LIMIT):
        result = c.post('/api/backups', headers=TOKEN)
        assert result.status_code == 201
    assert len(result.json['rows']) == BACKUP_LIMIT
    assert c.get(url, headers=TOKEN).status_code == 404
    assert len(c.get('/api/backups', headers=other).json['rows']) == 1


def test_compact_edition_migrates_legacy_cookie_workspace(tmp_path):
    import json
    import sqlite3

    path = tmp_path / 'compact.sqlite3'
    raw, ref = make_demo()
    report = run(raw, ref)
    key = '7' * 48
    old = {'raw': raw, 'ref': ref, 'clean': report['clean'], 'errors': report['errors'],
           'source': 'Свои файлы', 'files': {'raw': 'previous.xlsx', 'ref': 'reference.xlsx'},
           'settings': {'threshold': 80, 'hint': 60, 'split': 'equal'}}
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE workspaces (id TEXT PRIMARY KEY, data TEXT NOT NULL)')
        db.execute('INSERT INTO workspaces VALUES (?, ?)', (key, json.dumps(old)))
    app = create_app({'TESTING': True, 'STANDALONE': True, 'DATABASE': str(path)})
    c = app.test_client()
    assert c.get('/api/state', headers=TOKEN).json['source'] == 'demo'
    c.set_cookie('grader_workspace', key)
    assert c.get('/api/state').json['source'] == 'demo'  # Заголовок по-прежнему обязателен.
    state = c.get('/api/state', headers=TOKEN).json
    assert state['files']['raw'] == 'previous.xlsx'
    assert state['metrics']['cost'] == 248600000
    assert state['storage']['imports_count'] == 1
    assert c.get('/api/report', headers=TOKEN).status_code == 200


def test_type_filter_and_comparison_update_all_analytics(client):
    whole = client.get('/api/state').json
    assert whole['equipment_load']['utilization'] == pytest.approx(78)
    assert whole['changes']['cost']['whole']
    assert whole['changes']['cost']['current_period'] == '2026-04'
    assert {item['name'] for item in whole['equipment_load']['items']} == {'Грейдеры', 'Грузовики', 'Тракторы', 'Краны'}
    params = {'period': '2026-04', 'equipment': 'Грейдеры'}
    scoped = client.get('/api/state', query_string=params).json
    assert scoped['metrics'] == {'cost': 38200000, 'hours': 8500, 'fuel': 171000, 'volume': 41000}
    assert scoped['distance'] == 720
    assert scoped['equipment_load']['utilization'] == pytest.approx(100 * 85 / 102)
    assert len(scoped['equipment_load']['items']) == 3  # Легенда сохраняет контекст и остаётся переключаемой.
    assert scoped['changes']['hours']['delta'] == 2900
    assert scoped['changes']['hours']['percent'] == pytest.approx(100 * (85 - 56) / 56)
    assert len(scoped['recent']) == 1 and scoped['recent'][0]['status'] == 'completed'
    assert scoped['series'][0]['cost'] == 38200000
    assert client.get('/api/sites', query_string=params).json['rows'][0]['distance'] == 720
    assert client.get('/api/sites', query_string=params).json['total'] == 1
    detail = client.get('/api/metric/hours', query_string=params).json
    assert detail['value'] == 8500 and detail['total'] == 1
    site = client.get('/api/site', query_string={**params, 'name': 'Участок №1'}).json
    assert site['totals']['distance'] == 720 and site['rows'][0]['machine'] == 'ДЗ-98'
    record = client.get('/api/records/12').json
    assert record['totals']['plan_hours'] == 10200 and record['raw']['employee']
    assert client.get('/api/records/999').status_code == 404
    assert client.get('/api/metric/bogus').status_code == 404


def test_metric_export_and_sheet_column_validations(client):
    raw = workbook(['Участок', 'Машина', 'Вид работы', 'Затраты', 'Километраж', 'Сотрудник', 'Статус', 'Дата'],
                   ['уч. 1', 'М-10', 'Планировка', 100, '1,25', 'Оператор 01', 'В процессе', '2026-11-17'],
                   ['уч. 1', 'М-10', 'Планировка', 15, 1, 'Оператор 02', 'некорректный', '2026-11-16'])
    ref = workbook(['Участок', 'Машина', 'Вид работ', 'Тип техники'], ['Участок №1', 'М-10', 'Планировка', 'Бульдозер'])
    s = client.post('/api/import', headers=TOKEN, data={'raw': (raw, 'test.xlsx'), 'ref': (ref, 'ref.xlsx')}).json
    assert s['all_errors'] == 1 and s['distance'] == 125
    assert s['equipment_load']['basis'] == 'rows' and s['equipment_load']['utilization'] is None
    assert s['equipment_load']['items'][0]['name'] == 'Бульдозеры'
    journal = s['import_id']
    item = client.get('/api/records/2', headers=TOKEN, query_string={'journal': journal}).json
    assert item['raw']['employee'] == 'Оператор 01' and item['checked'][0]['status'] == 'in_progress'
    assert client.get(f'/api/records/2?journal={journal}').status_code == 404
    report = client.get('/api/report/metric/cost', headers=TOKEN, query_string={'period':'2026-11', 'equipment':'Бульдозеры'})
    wb = load_workbook(BytesIO(report.data), read_only=True)
    assert list(wb.active.values)[1][-1] == 100
    wb.close()


def test_postgresql_upload_details_and_backup():
    import os
    import sqlite3
    from tempfile import TemporaryDirectory
    from uuid import uuid4
    from storage import PostgresStorage

    dsn = os.getenv('GRADER_TEST_POSTGRES')
    if not dsn:
        pytest.skip('Проверка PostgreSQL: задайте GRADER_TEST_POSTGRES для тестовой базы.')
    app = create_app({'TESTING': True, 'DATABASE_URL': dsn})
    c = app.test_client()
    key = uuid4().hex
    header = {'X-Workspace': key}
    store = PostgresStorage(dsn)
    try:
        raw, ref = (c.get(f'/files/demo-{kind}.xlsx').data for kind in ('works', 'reference'))
        response = c.post('/api/import', headers=header, data={'raw': (BytesIO(raw), 'log.xlsx'), 'ref': (BytesIO(ref), 'ref.xlsx')})
        assert response.status_code == 200 and response.json['database'] == 'PostgreSQL'
        ident = response.json['import_id']
        assert response.json['equipment_load']['utilization'] == 78
        selected = c.get('/api/state', headers=header, query_string={'equipment':'Грейдеры', 'period':'2026-04'}).json
        assert selected['distance'] == 720 and selected['storage']['rows_count'] == 14
        snap = c.post('/api/backups', headers=header)
        assert snap.status_code == 201
        url = f"/api/backups/{snap.json['rows'][0]['id']}/file"
        assert c.get(url).status_code == 404
        with TemporaryDirectory() as temp:
            path = Path(temp) / 'copy.sqlite3'
            path.write_bytes(c.get(url, headers=header).data)
            with sqlite3.connect(path) as db:
                assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
                assert db.execute('PRAGMA foreign_key_check').fetchall() == []
                assert db.execute('SELECT COUNT(*) FROM employees').fetchone() == (4,)
                assert db.execute('SELECT COUNT(*) FROM finances').fetchone() == (14,)
                assert db.execute('SELECT COUNT(*) FROM equipment').fetchone() == (4,)
                assert db.execute('SELECT COUNT(*) FROM sites').fetchone() == (4,)
        assert c.get(f'/api/records/12?journal={ident}', headers=header).json['totals']['distance'] == 720
        assert c.post('/api/settings', headers=header, json={'threshold':.8, 'hint_min':.6, 'split_mode':'flag'}).json['all_errors'] == 4
        assert c.delete(f'/api/imports/{ident}', headers=header).status_code == 200
    finally:
        with store._transaction(write=True) as db:
            db.execute('DELETE FROM workspace_settings WHERE id=?', (key,))

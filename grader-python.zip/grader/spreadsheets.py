"""Импорт рабочих книг и создание шаблонов и отчётов Excel."""
from datetime import date, datetime
from io import BytesIO
from pathlib import Path
import re
from zipfile import ZipFile

import xlrd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.utils.datetime import from_excel

from engine import (RAW_FIELDS, REF_FIELDS, OPTIONAL_FIELDS, REF_OPTIONAL, MEASURES, STATUS_LABELS, group, in_period,
                    make_demo, text)
from analytics import site_totals

MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MAX_BYTES = 10 * 1024 * 1024
MAX_ROWS = 15_000
MAX_COLS = 128
MAX_UNZIPPED = 80 * 1024 * 1024
CASH_FORMAT = '#,##0.00'
SHEET_ALIASES = {
    "work": {"Вид работ", "Вид работы"}, "cost": {"Затраты (руб.)", "Затраты, руб.", "Затраты, ₽"},
    "date": {"Дата работ", "Месяц", "Период"},
    "volume": {"Объём", "Объём работ, м³", "Объём работ (м3)", "Объём работ, м3"},
    "fuel": {"Топливо", "Расход топлива, л", "Расход топлива (л)"},
    "hours": {"Машино-часы", "Моточасы, ч", "Моточасы (ч)"},
    "distance": {"Километраж", "Расстояние", "Км", "Расстояние, км", "Пройдено, км", "Длина, км"},
    "plan_hours": {"План моточасов", "Плановые моточасы, ч"},
    "employee": {"Оператор", "Водитель", "Машинист", "ФИО сотрудника"},
    "equipment_type": {"Вид техники", "Категория техники"},
}


def header_key(value):
    return re.sub(r"\W+", " ", text(value).casefold().replace("ё", "е")).strip()


def safe_value(value, row_number):
    if isinstance(value, (date, datetime)):
        return value.isoformat()[:10]
    if isinstance(value, str):
        value = value.replace("\x00", "")
        if len(value) > 500:
            raise ValueError(f"В строке {row_number} есть ячейка длиннее 500 символов.")
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if text(value) else None
    return text(value)


def read_rows(lines, kind, epoch=None):
    mandatory = RAW_FIELDS if kind == "raw" else REF_FIELDS
    fields = {**mandatory, **(OPTIONAL_FIELDS if kind == "raw" else REF_OPTIONAL)}
    choices = {header_key(label): key for key, title in fields.items()
               for label in {title, *SHEET_ALIASES.get(key, ())}}
    first = next(lines, None)
    if not first or not any(text(v) for v in first):
        raise ValueError("Первая строка листа должна содержать заголовки столбцов.")
    columns = {}
    for idx, cell in enumerate(first):
        match = choices.get(header_key(cell))
        if match in columns:
            raise ValueError(f"Столбец «{fields[match]}» указан дважды.")
        if match:
            columns[match] = idx
    missing = [name for key, name in mandatory.items() if key not in columns]
    if missing:
        raise ValueError("На первом листе не хватает столбцов: «" + "», «".join(missing) + "».")
    output = []
    for row_number, values in enumerate(lines, 2):
        if row_number > MAX_ROWS + 1:
            raise ValueError(f"На первом листе должно быть не более {MAX_ROWS:,} строк данных.".replace(",", " "))
        row = {}
        for key, idx in columns.items():
            value = values[idx] if idx < len(values) else None
            if key == "date" and epoch is not None and type(value) in (int, float) and 1 <= value < 2958466:
                try:
                    value = from_excel(value, epoch)
                except (ValueError, OverflowError):
                    pass
            row[key] = safe_value(value, row_number)
        if any(text(v) for v in row.values()):
            row["row"] = row_number
            output.append(row)
    if not output:
        raise ValueError("Первый лист не содержит строк данных.")
    return output


def read_upload(upload, kind):
    if not upload or not upload.filename:
        raise ValueError("Выберите Excel-файл.")
    suffix = Path(upload.filename).suffix.casefold()
    if suffix not in {".xlsx", ".xls"}:
        raise ValueError("Выберите книгу Excel с расширением .xlsx или .xls.")
    data = upload.stream.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError("Размер файла превышает 10 МБ.")
    try:
        if suffix == ".xlsx":
            with ZipFile(BytesIO(data)) as archive:
                if sum(item.file_size for item in archive.infolist()) > MAX_UNZIPPED:
                    raise ValueError("Книга слишком велика после распаковки.")
            wb = load_workbook(BytesIO(data), read_only=True, data_only=True, keep_links=False)
            try:
                if not wb.worksheets:
                    raise ValueError("В книге нет ни одного листа.")
                sheet = wb.worksheets[0]
                if sheet.max_column and sheet.max_column > MAX_COLS:
                    raise ValueError(f"На первом листе должно быть не более {MAX_COLS} столбцов.")
                width = sheet.max_column or MAX_COLS
                # При ограничении max_col не требуется полагаться на корректный размер листа по строкам.
                sheet.reset_dimensions()
                return read_rows(sheet.iter_rows(max_col=width, values_only=True), kind, wb.epoch)
            finally:
                wb.close()
        wb = xlrd.open_workbook(file_contents=data, on_demand=True)
        try:
            if not wb.nsheets:
                raise ValueError("В книге нет ни одного листа.")
            sheet = wb.sheet_by_index(0)
            if sheet.ncols > MAX_COLS:
                raise ValueError(f"На первом листе должно быть не более {MAX_COLS} столбцов.")

            def xls_lines():
                for idx in range(sheet.nrows):
                    values = []
                    for cell in sheet.row(idx):
                        try:
                            if cell.ctype == xlrd.XL_CELL_DATE:
                                value = xlrd.xldate_as_datetime(cell.value, wb.datemode)
                            elif cell.ctype == xlrd.XL_CELL_BOOLEAN:
                                value = bool(cell.value)
                            elif cell.ctype == xlrd.XL_CELL_ERROR:
                                value = xlrd.error_text_from_code.get(cell.value, "Ошибка Excel")
                            else:
                                value = cell.value
                        except (ValueError, OverflowError):
                            value = cell.value
                        values.append(value)
                    yield values

            return read_rows(xls_lines(), kind, datetime(1904, 1, 1) if wb.datemode else None)
        finally:
            wb.release_resources()
    except ValueError:
        raise
    except Exception:
        raise ValueError("Не удалось открыть книгу. Проверьте, что это читаемый файл Excel без пароля.") from None


def add_sheet(wb, name, fields, rows, monetary=()):
    ws = wb.create_sheet(name)
    ws.append(list(fields.values()))
    ws.freeze_panes = "A2"
    ws.sheet_view.showGridLines = False
    ws.row_dimensions[1].height = 25
    for i, (key, title) in enumerate(fields.items(), 1):
        cell = ws.cell(1, i)
        cell.font = Font(name="Calibri", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="246568")
        cell.alignment = Alignment(vertical="center")
        width = {"raw": 56, "issue": 54, "hint": 50, "note": 32, "name": 28, "work": 24,
                 "machine": 20, "site": 19, "row": 12}.get(key, max(16, len(title) + 5))
        ws.column_dimensions[get_column_letter(i)].width = width
    for idx, row in enumerate(rows, 2):
        for col, key in enumerate(fields, 1):
            value = row.get(key)
            cell = ws.cell(idx, col, value)
            if isinstance(value, str):
                cell.data_type = "s"  # Текст из входных файлов не становится формулой.
            if key in monetary and value is not None:
                cell.number_format = CASH_FORMAT
            if key in ("raw", "issue", "hint", "note"):
                cell.alignment = Alignment(vertical="top", wrap_text=True)
            elif isinstance(value, date):
                cell.number_format = "dd.mm.yyyy"
        if name == "Ошибки":
            ws.row_dimensions[idx].height = 34
    ws.auto_filter.ref = ws.dimensions
    return ws


def finish(wb):
    buffer = BytesIO()
    wb.save(buffer)
    wb.close()
    buffer.seek(0)
    return buffer


def report_line(row):
    numeric = ("cost", *MEASURES)
    entry = {**row, **{key: row[key] / 100 if row.get(key) is not None else None for key in numeric}}
    if row.get("date") and len(row["date"]) == 10:
        entry["date"] = date.fromisoformat(row["date"])
    entry["status"] = STATUS_LABELS.get(row.get("status"), "Проверено")
    return entry


def detail_fields(rows):
    fields = {**RAW_FIELDS, "row": "Строка", "note": "Примечание"}
    fields.update({key: title for key, title in {**OPTIONAL_FIELDS, **REF_OPTIONAL}.items()
                   if any(r.get(key) is not None for r in rows)})
    return fields


def workbook_for_report(report, period=None):
    clean = in_period(report["clean"], period)
    errors = in_period(report["errors"], period)
    wb = Workbook()
    wb.remove(wb.active)
    add_sheet(wb, "Чистый результат", detail_fields(clean), map(report_line, clean), ("cost", *MEASURES))
    for field, name in (("site", "По участкам"), ("machine", "По машинам"), ("work", "По видам работ")):
        add_sheet(wb, name, {"name": "Название", "cost": "Затраты", "count": "Записей"},
                  ({**r, "cost": r["cost"] / 100} for r in group(clean, field)), ("cost",))
    add_sheet(wb, "Ошибки", {"row": "Строка", "raw": "Исходные данные", "issue": "Причина", "hint": "Подсказка"}, errors)
    return finish(wb)


def workbook_for_sites(report, period=None):
    clean = in_period(report["clean"], period)
    wb = Workbook()
    wb.remove(wb.active)
    grouped = site_totals(clean)
    fields = {"name": "Участок", "cost": "Затраты", "count": "Записей",
              **{k: OPTIONAL_FIELDS[k] for k in ("distance", "volume", "hours", "fuel")}}
    numeric = ("cost", "distance", "volume", "hours", "fuel")
    add_sheet(wb, "Отчёт по участкам", fields,
              ({**row, **{k: row[k] / 100 if row[k] is not None else None for k in numeric}} for row in grouped), numeric)
    add_sheet(wb, "История работ", detail_fields(clean), map(report_line, clean), ("cost", *MEASURES))
    return finish(wb)


def workbook_for_metric(clean, key):
    wb = Workbook()
    wb.remove(wb.active)
    fields = {"date": "Дата", "site": "Участок", "machine": "Машина", "equipment_type": "Тип техники",
              "work": "Вид работы", "row": "Строка", key: ("Затраты" if key == "cost" else OPTIONAL_FIELDS[key])}
    add_sheet(wb, "Детализация показателя", fields, (report_line(row) for row in clean if row.get(key) is not None), (key,))
    return finish(wb)


def workbook_for_input(kind, demo):
    raw, ref = make_demo() if demo else ([], [])
    wb = Workbook()
    wb.remove(wb.active)
    if kind == "raw":
        rows = ({**row, "date": date.fromisoformat(row["date"])} for row in raw)
        add_sheet(wb, "Журнал работ", {**RAW_FIELDS, **OPTIONAL_FIELDS}, rows, ("cost", *MEASURES))
    else:
        add_sheet(wb, "Справочник", {**REF_FIELDS, **REF_OPTIONAL}, ref)
    return finish(wb)
